# 🎛️ Guia Completo - Dashboard Master Downloader

## 📋 O Que é o Dashboard?

Um **painel de controle web profissional** que permite:

✅ **Controle Total** - Iniciar, pausar, retomar, cancelar
✅ **Logs em Tempo Real** - Acompanhe cada ação
✅ **Progresso Visual** - Gráficos e barras de progresso
✅ **Estatísticas** - Páginas, imagens, propriedades, erros
✅ **Configuração Dinâmica** - Mude URL e parâmetros
✅ **Arquivos Gerados** - Veja o que foi baixado
✅ **Interface Moderna** - Bonita e responsiva

---

## 🚀 Instalação no Windows

### Passo 1: Instalar Dependências

Abra o **Prompt de Comando** e execute:

```bash
pip install flask flask-socketio flask-cors python-socketio python-engineio selenium beautifulsoup4 requests
```

Você deve ver:
```
Successfully installed flask-3.0.0 flask-socketio-5.3.0 ...
```

---

### Passo 2: Preparar Arquivos

1. Crie uma pasta: `C:\Users\SeuUsuario\Downloads\master_dashboard`

2. Copie os arquivos:
   - `app_dashboard.py` (servidor)
   - `imobssa_master_downloader.py` (script master)
   - `templates_dashboard.html` (interface)

3. Crie uma subpasta: `templates`

4. Mova `templates_dashboard.html` para `templates/dashboard.html`

Estrutura final:
```
master_dashboard/
├── app_dashboard.py
├── imobssa_master_downloader.py
└── templates/
    └── dashboard.html
```

---

### Passo 3: Rodar o Dashboard

Abra o **Prompt de Comando** na pasta e execute:

```bash
python app_dashboard.py
```

Você verá:
```
======================================================================
MASTER DOWNLOADER DASHBOARD
======================================================================

🌐 Abrindo navegador em: http://localhost:5000
⚠️  Não feche esta janela!

======================================================================
```

---

### Passo 4: Abrir no Navegador

Abra seu navegador e acesse:

```
http://localhost:5000
```

Você verá o dashboard!

---

## 🎯 Como Usar o Dashboard

### 1. Configurar

Na seção **⚙️ Configuração**:

- **URL do Site**: Cole a URL que deseja clonar
- **Pasta de Saída**: Nome da pasta onde salvar
- **Máximo de Páginas**: Quantas páginas processar

Exemplo:
```
URL: https://www.shopee.com.br
Pasta: shopee_clone
Páginas: 50
```

---

### 2. Iniciar Download

Clique em **▶️ Iniciar Download**

O dashboard mostrará:
- ✓ Logs em tempo real
- ✓ Progresso visual
- ✓ Estatísticas atualizadas
- ✓ Tempo decorrido

---

### 3. Controlar Execução

Durante o download:

- **⏸️ Pausar** - Pausa a execução
- **▶️ Retomar** - Continua de onde parou
- **⛔ Cancelar** - Para tudo

---

### 4. Acompanhar Progresso

O dashboard mostra em tempo real:

```
📊 Progresso em Tempo Real

Progresso Geral: ████████░░ 80%

Páginas: 16
Imagens: 245
Propriedades: 128
Erros: 2

Tempo Decorrido: 05:23:15
```

---

### 5. Visualizar Logs

Na seção **📋 Logs em Tempo Real**:

```
[12:34:56] ℹ️ Conectado ao servidor
[12:34:57] ▶️ Download iniciado
[12:35:00] ✓ Página 1 processada
[12:35:02] ✓ 5 imagens baixadas
[12:35:04] ⚠️ Imagem bloqueada (403)
[12:35:06] ✓ Dados salvos
```

Cada cor representa um tipo de mensagem:
- 🔵 **Azul** = Informação
- 🟢 **Verde** = Sucesso
- 🟡 **Amarelo** = Aviso
- 🔴 **Vermelho** = Erro

---

### 6. Ver Arquivos Gerados

Na seção **📁 Arquivos Gerados**:

Mostra todos os arquivos criados com seus tamanhos:

```
📄 index.html (45 KB)
📄 layout.css (12 KB)
📄 jquery.js (89 KB)
📄 database.json (2.3 MB)
📄 properties.csv (1.2 MB)
```

---

## 📊 Recursos do Dashboard

### Barra de Progresso

```
Progresso Geral
████████░░ 80%
```

Mostra o percentual de conclusão baseado no número de páginas processadas.

---

### Estatísticas em Tempo Real

```
┌─────────────┬─────────────┬─────────────┬─────────────┐
│   Páginas   │   Imagens   │ Propriedades│   Erros     │
│      16     │     245     │     128     │      2      │
└─────────────┴─────────────┴─────────────┴─────────────┘
```

Atualizam a cada segundo durante a execução.

---

### Tempo Decorrido

```
Tempo Decorrido
05:23:15
```

Mostra quanto tempo a execução levou até agora.

---

## 🔧 Configurações Avançadas

### Aumentar Número de Páginas

No dashboard, mude o campo "Máximo de Páginas" para um valor maior:

```
Máximo de Páginas: 100
```

---

### Usar com Outro Site

No dashboard, mude a URL:

```
URL do Site: https://www.seu-site.com.br
Pasta de Saída: seu_site_clone
```

Exemplos:
- Shopee: `https://www.shopee.com.br`
- Mercado Livre: `https://www.mercadolivre.com.br`
- G1: `https://www.g1.globo.com`

---

### Modo Headless (Sem Navegador)

Edite `app_dashboard.py` e procure por:

```python
# options.add_argument('--headless')
```

Descomente para não ver o navegador:

```python
options.add_argument('--headless')
```

---

## 🆘 Problemas Comuns

### Problema 1: "Porta 5000 já está em uso"

**Solução:**
1. Feche outras aplicações que usam a porta 5000
2. Ou mude a porta no final de `app_dashboard.py`:

```python
# De:
socketio.run(app, host='0.0.0.0', port=5000, debug=False)

# Para:
socketio.run(app, host='0.0.0.0', port=8000, debug=False)
```

Então acesse: `http://localhost:8000`

---

### Problema 2: "ModuleNotFoundError: No module named 'flask'"

**Solução:**
```bash
pip install flask flask-socketio flask-cors
```

---

### Problema 3: Dashboard não conecta

**Solução:**
1. Verifique se o servidor está rodando (veja a janela do Prompt)
2. Tente atualizar a página (F5)
3. Verifique se a URL está correta: `http://localhost:5000`

---

### Problema 4: Download muito lento

**Solução:**
- Reduzir número de páginas
- Aumentar timeout no script
- Usar internet mais rápida

---

## 📱 Responsividade

O dashboard funciona em:
- ✅ Desktop (Windows, Mac, Linux)
- ✅ Tablet
- ✅ Smartphone

Basta acessar de qualquer dispositivo na mesma rede:

```
http://seu-ip-local:5000
```

Para encontrar seu IP local:
```bash
ipconfig
```

Procure por "IPv4 Address" (ex: 192.168.1.100)

---

## 🎨 Customização

### Mudar Cores

Edite `templates/dashboard.html` e procure por:

```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

Mude para suas cores favoritas.

---

### Mudar Título

Edite `templates/dashboard.html`:

```html
<h1>🎛️ Master Downloader Dashboard</h1>
```

---

### Adicionar Mais Estatísticas

Edite `app_dashboard.py` e adicione novos campos em `DashboardLogger.stats`.

---

## 📊 Estrutura de Dados

O dashboard envia/recebe dados em JSON:

```json
{
  "base_url": "https://imobssa.com.br",
  "output_dir": "imobssa_master_clone",
  "max_pages": 20,
  "stats": {
    "pages_processed": 16,
    "images_downloaded": 245,
    "properties_found": 128,
    "errors": 2,
    "warnings": 5
  }
}
```

---

## 🚀 Próximos Passos

### 1. Testar com ImobSSA

```
URL: https://imobssa.com.br
Páginas: 10
```

Clique em "Iniciar" e acompanhe o progresso.

---

### 2. Testar com Outro Site

```
URL: https://www.seu-site.com.br
Páginas: 20
```

---

### 3. Exportar Dados

Após o download, você terá:
- `database.json` - Todos os dados
- `properties.csv` - Em formato Excel
- `MASTER_REPORT.md` - Relatório detalhado

---

## 💡 Dicas Profissionais

✅ **Boas Práticas:**
- Comece com poucas páginas (5-10)
- Aumente gradualmente
- Respeite o servidor (delays entre requisições)
- Verifique o `robots.txt` do site

❌ **Não Faça:**
- Não configure `max_pages` muito alto
- Não execute múltiplos downloads simultaneamente
- Não republique conteúdo protegido

---

## 📞 Suporte

Se tiver problemas:

1. Verifique os logs no dashboard
2. Leia o arquivo `MASTER_REPORT.md` gerado
3. Consulte a documentação do Selenium
4. Verifique se ChromeDriver está instalado

---

## 🎓 Recursos

- **Flask Docs:** https://flask.palletsprojects.com/
- **Socket.IO Docs:** https://socket.io/docs/
- **Selenium Docs:** https://www.selenium.dev/documentation/

---

**Versão:** 1.0 Dashboard
**Data:** 2026-04-09
**Sistema:** Windows 10/11 (também funciona em Mac/Linux)
