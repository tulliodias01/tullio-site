#!/usr/bin/env python3
"""
MASTER DOWNLOADER DASHBOARD
Dashboard em Tempo Real com Flask + WebSocket
Controle total do script Selenium
"""

from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS
import threading
import time
import json
import os
from datetime import datetime
from pathlib import Path
import logging
from queue import Queue
import sys

# Importar o script master
sys.path.insert(0, '/home/ubuntu')
from imobssa_master_downloader import ImobssaMasterDownloader

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Criar app Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Variáveis globais
downloader = None
download_thread = None
is_running = False
is_paused = False
download_config = {
    'base_url': 'https://imobssa.com.br',
    'output_dir': 'imobssa_master_clone',
    'max_pages': 20
}

# Fila de eventos
event_queue = Queue()

class DashboardLogger:
    """Logger customizado que envia eventos para o dashboard"""
    
    def __init__(self, socketio):
        self.socketio = socketio
        self.start_time = time.time()
        self.stats = {
            'pages_processed': 0,
            'images_downloaded': 0,
            'properties_found': 0,
            'errors': 0,
            'warnings': 0
        }
    
    def log(self, level, message):
        """Log com envio para dashboard"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        log_entry = {
            'timestamp': timestamp,
            'level': level,
            'message': message
        }
        
        # Emitir para todos os clientes conectados
        self.socketio.emit('log_entry', log_entry, broadcast=True)
        
        # Também imprimir no console
        print(f"[{timestamp}] [{level}] {message}")
        
        # Atualizar estatísticas
        if level == 'success':
            if 'página' in message.lower() or 'page' in message.lower():
                self.stats['pages_processed'] += 1
            elif 'imagem' in message.lower() or 'image' in message.lower():
                self.stats['images_downloaded'] += 1
            elif 'propriedade' in message.lower() or 'property' in message.lower():
                self.stats['properties_found'] += 1
        elif level == 'error':
            self.stats['errors'] += 1
        elif level == 'warning':
            self.stats['warnings'] += 1
        
        # Emitir estatísticas atualizadas
        self.socketio.emit('stats_update', self.stats, broadcast=True)
    
    def info(self, message):
        self.log('info', message)
    
    def success(self, message):
        self.log('success', message)
    
    def warning(self, message):
        self.log('warning', message)
    
    def error(self, message):
        self.log('error', message)
    
    def get_progress(self):
        """Calcula progresso"""
        elapsed = time.time() - self.start_time
        return {
            'elapsed_time': elapsed,
            'pages_processed': self.stats['pages_processed'],
            'images_downloaded': self.stats['images_downloaded'],
            'properties_found': self.stats['properties_found'],
            'errors': self.stats['errors'],
            'warnings': self.stats['warnings']
        }

# Instanciar logger
dashboard_logger = DashboardLogger(socketio)

def run_download():
    """Executa o download em thread separada"""
    global downloader, is_running, is_paused
    
    try:
        dashboard_logger.info(f"🚀 Iniciando download de {download_config['base_url']}")
        
        downloader = ImobssaMasterDownloader(
            base_url=download_config['base_url'],
            output_dir=download_config['output_dir'],
            max_pages=download_config['max_pages']
        )
        
        # Substituir print do downloader pelo nosso logger
        downloader.logger = dashboard_logger
        
        dashboard_logger.info("📁 Criando diretórios...")
        downloader.create_directories()
        
        dashboard_logger.info("🌐 Inicializando Selenium...")
        if not downloader.setup_selenium():
            dashboard_logger.error("❌ Erro ao inicializar Selenium")
            is_running = False
            return
        
        dashboard_logger.success("✓ Selenium inicializado com sucesso")
        
        dashboard_logger.info("🕷️ Iniciando crawling...")
        downloader.crawl_site()
        
        dashboard_logger.info("💾 Consolidando dados...")
        for page in downloader.all_data['pages']:
            downloader.all_data['properties'].extend(page.get('properties', []))
        
        dashboard_logger.info("📊 Gerando banco de dados...")
        downloader.generate_database()
        
        dashboard_logger.info("📋 Exportando para CSV...")
        downloader.generate_csv_export()
        
        dashboard_logger.info("📄 Gerando relatório...")
        downloader.generate_report()
        
        dashboard_logger.success("✅ Download concluído com sucesso!")
        
        # Emitir evento de conclusão
        socketio.emit('download_complete', {
            'status': 'success',
            'message': 'Download concluído com sucesso!',
            'output_dir': download_config['output_dir'],
            'stats': dashboard_logger.stats
        }, broadcast=True)
        
    except Exception as e:
        dashboard_logger.error(f"❌ Erro durante execução: {str(e)}")
        socketio.emit('download_error', {
            'status': 'error',
            'message': str(e)
        }, broadcast=True)
    
    finally:
        if downloader and downloader.driver:
            downloader.driver.quit()
        is_running = False

# ==================== ROTAS ====================

@app.route('/')
def index():
    """Página principal do dashboard"""
    return render_template('dashboard.html')

@app.route('/api/config', methods=['GET'])
def get_config():
    """Retorna configuração atual"""
    return jsonify(download_config)

@app.route('/api/config', methods=['POST'])
def update_config():
    """Atualiza configuração"""
    global download_config
    data = request.json
    download_config.update(data)
    return jsonify({'status': 'success', 'config': download_config})

@app.route('/api/status', methods=['GET'])
def get_status():
    """Retorna status atual"""
    return jsonify({
        'is_running': is_running,
        'is_paused': is_paused,
        'progress': dashboard_logger.get_progress()
    })

# ==================== WEBSOCKET EVENTS ====================

@socketio.on('connect')
def handle_connect():
    """Cliente conectado"""
    dashboard_logger.info(f"👤 Cliente conectado: {request.sid}")
    emit('connection_response', {'data': 'Conectado ao Dashboard'})

@socketio.on('disconnect')
def handle_disconnect():
    """Cliente desconectado"""
    dashboard_logger.info(f"👤 Cliente desconectado: {request.sid}")

@socketio.on('start_download')
def handle_start_download(data):
    """Inicia o download"""
    global download_thread, is_running, is_paused
    
    if is_running:
        emit('error', {'message': 'Download já está em execução'})
        return
    
    # Atualizar configuração
    if data:
        download_config.update(data)
    
    is_running = True
    is_paused = False
    
    dashboard_logger.info("▶️ Download iniciado pelo usuário")
    
    # Iniciar thread de download
    download_thread = threading.Thread(target=run_download, daemon=True)
    download_thread.start()
    
    emit('download_started', {'status': 'started'}, broadcast=True)

@socketio.on('pause_download')
def handle_pause_download():
    """Pausa o download"""
    global is_paused
    
    if not is_running:
        emit('error', {'message': 'Nenhum download em execução'})
        return
    
    is_paused = True
    dashboard_logger.warning("⏸️ Download pausado pelo usuário")
    emit('download_paused', {'status': 'paused'}, broadcast=True)

@socketio.on('resume_download')
def handle_resume_download():
    """Retoma o download"""
    global is_paused
    
    if not is_running:
        emit('error', {'message': 'Nenhum download em execução'})
        return
    
    is_paused = False
    dashboard_logger.info("▶️ Download retomado pelo usuário")
    emit('download_resumed', {'status': 'resumed'}, broadcast=True)

@socketio.on('cancel_download')
def handle_cancel_download():
    """Cancela o download"""
    global is_running, downloader
    
    if not is_running:
        emit('error', {'message': 'Nenhum download em execução'})
        return
    
    is_running = False
    
    if downloader and downloader.driver:
        downloader.driver.quit()
    
    dashboard_logger.warning("⛔ Download cancelado pelo usuário")
    emit('download_cancelled', {'status': 'cancelled'}, broadcast=True)

@socketio.on('clear_logs')
def handle_clear_logs():
    """Limpa os logs"""
    dashboard_logger.stats = {
        'pages_processed': 0,
        'images_downloaded': 0,
        'properties_found': 0,
        'errors': 0,
        'warnings': 0
    }
    emit('logs_cleared', {'status': 'cleared'}, broadcast=True)

@socketio.on('get_output_files')
def handle_get_output_files():
    """Lista arquivos gerados"""
    output_path = Path(download_config['output_dir'])
    
    if not output_path.exists():
        emit('output_files', {'files': []})
        return
    
    files = []
    for root, dirs, filenames in os.walk(output_path):
        for filename in filenames:
            filepath = os.path.join(root, filename)
            rel_path = os.path.relpath(filepath, output_path)
            files.append({
                'name': filename,
                'path': rel_path,
                'size': os.path.getsize(filepath)
            })
    
    emit('output_files', {'files': files}, broadcast=True)

# ==================== MAIN ====================

if __name__ == '__main__':
    print("\n" + "="*70)
    print("MASTER DOWNLOADER DASHBOARD")
    print("="*70)
    print("\n🌐 Abrindo navegador em: http://localhost:5000")
    print("⚠️  Não feche esta janela!")
    print("\n" + "="*70 + "\n")
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
