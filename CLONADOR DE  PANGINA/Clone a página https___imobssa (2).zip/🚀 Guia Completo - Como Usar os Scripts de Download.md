# 🚀 Guia Completo - Como Usar os Scripts de Download

## 📋 Índice
1. [Pré-requisitos](#pré-requisitos)
2. [Como Rodar os Scripts](#como-rodar-os-scripts)
3. [Adaptando para Outros Sites](#adaptando-para-outros-sites)
4. [Exemplos Práticos](#exemplos-práticos)
5. [Troubleshooting](#troubleshooting)

---

## Pré-requisitos

### Instalar Python 3
```bash
# Linux/Mac
python3 --version

# Se não tiver, instale:
# Ubuntu/Debian
sudo apt-get install python3 python3-pip

# Mac
brew install python3
```

### Instalar Dependências
```bash
pip3 install requests beautifulsoup4
```

---

## Como Rodar os Scripts

### Opção 1: Script de Análise Técnica (Rápido)

```bash
# Navegar até o diretório
cd /home/ubuntu

# Executar o script
python3 imobssa_scraper.py
```

**O que ele faz:**
- Analisa a estrutura técnica
- Gera `imobssa_technical_report.json`
- Gera `TECHNICAL_ANALYSIS.md`
- Leva ~5 segundos

**Saída esperada:**
```
Iniciando scraping de https://imobssa.com.br...
Extraindo metadados...
Extraindo scripts...
Extraindo stylesheets...
Extraindo formulários...
Extraindo propriedades...
Detectando endpoints de API...
Analisando estrutura...
Relatório salvo em imobssa_technical_report.json
Documentação salva em TECHNICAL_ANALYSIS.md
==================================================
RESUMO DA ANÁLISE
==================================================
Scripts: 6
Stylesheets: 4
Formulários: 3
Propriedades encontradas: 1
Endpoints de API: 0
Stack: ['facebook_pixel', 'google_analytics', 'jquery']
```

---

### Opção 2: Script de Download Completo (Completo)

```bash
# Navegar até o diretório
cd /home/ubuntu

# Executar o script
python3 imobssa_complete_downloader.py
```

**O que ele faz:**
- Baixa HTML completo
- Baixa todos os CSS
- Baixa todos os JavaScript
- Baixa imagens (até 50)
- Extrai estrutura de dados
- Gera guia de reconstrução
- Cria relatório de download

**Saída esperada:**
```
============================================================
IMOBSSA COMPLETE DOWNLOADER
============================================================
✓ Diretórios criados em: imobssa_clone
[1/6] Baixando HTML...
✓ HTML baixado: imobssa_clone/html/index.html
[2/6] Baixando Stylesheets...
✓ CSS baixado: layout.css
[3/6] Baixando Scripts...
✓ JS baixado: jquerymin132.js
[4/6] Baixando Imagens (limite: 50)...
✓ Imagem baixada: thumb15-202604021242408531.jpg
[5/6] Extraindo Estrutura de Dados...
✓ Estrutura de dados extraída: imobssa_clone/data/structure.json
[6/6] Gerando Guia de Reconstrução...
✓ Guia de reconstrução: imobssa_clone/docs/RECONSTRUCTION_GUIDE.md

============================================================
RESUMO DO DOWNLOAD
============================================================
Data: 2026-04-09 12:00:00
Origem: https://imobssa.com.br
Destino: imobssa_clone

Arquivos Baixados:
  - HTML: 1
  - CSS: 4
  - JS: 6
  - Imagens: 40
  - Total: 51

Tamanho Total: 2.45 MB
============================================================
```

**Arquivos gerados:**
```
imobssa_clone/
├── html/
│   └── index.html
├── css/
│   ├── layout.css
│   ├── ddsmoothmenu.css
│   ├── ddsmoothmenu-v.css
│   └── whatsapplead.css
├── js/
│   ├── jquerymin132.js
│   ├── stepcarousel.js
│   ├── jquery.min.js
│   ├── ddsmoothmenu.js
│   └── analytics.js
├── images/
│   ├── thumb15-202604021242408531.jpg
│   ├── vn_atend_foneb.png
│   └── ... (mais imagens)
├── data/
│   └── structure.json
└── docs/
    ├── RECONSTRUCTION_GUIDE.md
    └── download_report.json
```

---

## Adaptando para Outros Sites

### Método 1: Script de Análise (Simples)

Edite o arquivo `imobssa_scraper.py` e mude apenas esta linha:

```python
# ANTES (linha ~10)
scraper = ImobssaScraper()

# DEPOIS - Para outro site
scraper = ImobssaScraper(base_url="https://seu-site.com.br")
```

**Exemplos:**
```python
# Para um e-commerce
scraper = ImobssaScraper(base_url="https://www.shopee.com.br")

# Para um portal de notícias
scraper = ImobssaScraper(base_url="https://www.g1.globo.com")

# Para um site de viagens
scraper = ImobssaScraper(base_url="https://www.booking.com")
```

Depois execute:
```bash
python3 imobssa_scraper.py
```

---

### Método 2: Script de Download Completo (Avançado)

Edite o arquivo `imobssa_complete_downloader.py`:

```python
# ANTES (última linha do arquivo)
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader()
    downloader.download_all()

# DEPOIS - Para outro site
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader(
        base_url="https://seu-site.com.br",
        output_dir="seu_site_clone"
    )
    downloader.download_all()
```

**Exemplos completos:**

```python
# E-commerce
downloader = ImobssaCompleteDownloader(
    base_url="https://www.amazon.com.br",
    output_dir="amazon_clone"
)

# Portal de notícias
downloader = ImobssaCompleteDownloader(
    base_url="https://www.uol.com.br",
    output_dir="uol_clone"
)

# Site de streaming
downloader = ImobssaCompleteDownloader(
    base_url="https://www.netflix.com",
    output_dir="netflix_clone"
)
```

Depois execute:
```bash
python3 imobssa_complete_downloader.py
```

---

## Exemplos Práticos

### Exemplo 1: Baixar Site de Imóvel Concorrente

```bash
# 1. Copie o script
cp imobssa_complete_downloader.py vivareal_downloader.py

# 2. Edite o arquivo (última linha)
# Mude: base_url="https://imobssa.com.br"
# Para: base_url="https://www.vivareal.com.br"

# 3. Execute
python3 vivareal_downloader.py
```

---

### Exemplo 2: Criar Script Genérico

Crie um arquivo `download_any_site.py`:

```python
#!/usr/bin/env python3
import sys
from imobssa_complete_downloader import ImobssaCompleteDownloader

if len(sys.argv) < 2:
    print("Uso: python3 download_any_site.py <URL> [output_dir]")
    print("Exemplo: python3 download_any_site.py https://exemplo.com.br meu_clone")
    sys.exit(1)

url = sys.argv[1]
output_dir = sys.argv[2] if len(sys.argv) > 2 else "site_clone"

downloader = ImobssaCompleteDownloader(base_url=url, output_dir=output_dir)
downloader.download_all()
```

**Como usar:**
```bash
# Qualquer site
python3 download_any_site.py https://www.exemplo.com.br meu_clone

# Com URL e diretório customizado
python3 download_any_site.py https://www.shopee.com.br shopee_clone

# Apenas URL (usa "site_clone" como padrão)
python3 download_any_site.py https://www.mercadolivre.com.br
```

---

### Exemplo 3: Batch Download (Múltiplos Sites)

Crie um arquivo `download_multiple.py`:

```python
#!/usr/bin/env python3
from imobssa_complete_downloader import ImobssaCompleteDownloader

sites = [
    ("https://www.imobssa.com.br", "imobssa_clone"),
    ("https://www.vivareal.com.br", "vivareal_clone"),
    ("https://www.imovelweb.com.br", "imovelweb_clone"),
]

for url, output_dir in sites:
    print(f"\n{'='*60}")
    print(f"Baixando: {url}")
    print(f"{'='*60}")
    
    downloader = ImobssaCompleteDownloader(base_url=url, output_dir=output_dir)
    downloader.download_all()
    
    print(f"✓ Concluído: {output_dir}\n")
```

**Como usar:**
```bash
python3 download_multiple.py
```

---

## Troubleshooting

### Problema 1: "ModuleNotFoundError: No module named 'requests'"

**Solução:**
```bash
pip3 install requests beautifulsoup4
```

---

### Problema 2: "Connection refused" ou "Timeout"

**Causas:**
- Site bloqueou seu IP
- Servidor está fora do ar
- Conexão de internet lenta

**Solução:**
```python
# Edite o script e aumente o timeout
# Procure por: timeout=10
# Mude para: timeout=30

# Ou adicione delay entre requisições
import time
time.sleep(2)  # Aguarda 2 segundos
```

---

### Problema 3: "403 Forbidden" em algumas imagens

**Causa:** Site bloqueia downloads diretos

**Solução:** Edite o script para usar User-Agent diferente
```python
self.session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
})
```

---

### Problema 4: Arquivo muito grande

**Solução:** Limitar número de imagens
```python
# Edite a linha que chama download_images
# De: self.download_images(html_content, limit=50)
# Para: self.download_images(html_content, limit=10)
```

---

## Dicas Importantes

### ✅ Boas Práticas

1. **Respeite o servidor** - Adicione delays entre requisições
   ```python
   time.sleep(0.5)  # 500ms entre requisições
   ```

2. **Use User-Agent realista** - Alguns sites bloqueiam bots
   ```python
   'User-Agent': 'Mozilla/5.0 ...'
   ```

3. **Trate erros** - Nem todas as imagens podem ser baixadas
   ```python
   try:
       response = self.session.get(url, timeout=10)
   except Exception as e:
       print(f"Erro: {e}")
   ```

4. **Verifique permissões** - Leia o `robots.txt` do site
   ```
   https://seu-site.com.br/robots.txt
   ```

---

### ⚠️ Avisos Legais

- Use apenas para fins educacionais e de desenvolvimento
- Respeite os termos de serviço do site
- Não republique conteúdo protegido por direitos autorais
- Alguns sites podem bloquear scraping automático

---

## Próximos Passos

Depois de baixar o site:

1. **Analise a estrutura**
   ```bash
   cat imobssa_clone/data/structure.json
   ```

2. **Leia o guia de reconstrução**
   ```bash
   cat imobssa_clone/docs/RECONSTRUCTION_GUIDE.md
   ```

3. **Customize o design**
   - Edite os arquivos CSS em `imobssa_clone/css/`
   - Modifique o HTML em `imobssa_clone/html/`

4. **Implemente suas funcionalidades**
   - Adicione backend
   - Conecte banco de dados
   - Integre com suas APIs

---

## Suporte

Para dúvidas:
- Consulte a documentação dos scripts
- Verifique os arquivos JSON gerados
- Leia o guia de reconstrução automático

---

**Última atualização:** 2026-04-09
**Versão:** 1.0
