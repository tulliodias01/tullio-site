#!/usr/bin/env python3
"""
IMOBSSA MASTER DOWNLOADER v2.0
Script Avançado com Selenium para Captura 100% do Site
- Captura dados dinâmicos (JavaScript/AJAX)
- Crawling de múltiplas páginas
- Renderização completa do navegador
- Extração de dados estruturados
- Geração de banco de dados local
"""

import os
import json
import time
import re
from pathlib import Path
from urllib.parse import urljoin, urlparse
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from bs4 import BeautifulSoup
import requests

class ImobssaMasterDownloader:
    def __init__(self, base_url="https://imobssa.com.br", output_dir="imobssa_master_clone", max_pages=50):
        self.base_url = base_url
        self.output_dir = output_dir
        self.max_pages = max_pages
        self.driver = None
        self.visited_urls = set()
        self.all_data = {
            'metadata': {},
            'pages': [],
            'properties': [],
            'forms': [],
            'images': [],
            'scripts': [],
            'stylesheets': [],
            'links': [],
            'api_calls': []
        }
        
        # Estrutura de diretórios
        self.dirs = {
            'root': output_dir,
            'html': os.path.join(output_dir, 'html'),
            'css': os.path.join(output_dir, 'css'),
            'js': os.path.join(output_dir, 'js'),
            'images': os.path.join(output_dir, 'images'),
            'data': os.path.join(output_dir, 'data'),
            'docs': os.path.join(output_dir, 'docs'),
            'screenshots': os.path.join(output_dir, 'screenshots')
        }
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def setup_selenium(self):
        """Configura o Selenium WebDriver"""
        print("\n[SETUP] Inicializando Selenium WebDriver...")
        
        options = webdriver.ChromeOptions()
        # options.add_argument('--headless')  # Comentado para ver o navegador
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        try:
            self.driver = webdriver.Chrome(options=options)
            print("✓ WebDriver iniciado com sucesso")
            return True
        except Exception as e:
            print(f"✗ Erro ao inicializar WebDriver: {e}")
            print("  Instale ChromeDriver: https://chromedriver.chromium.org/")
            return False
    
    def create_directories(self):
        """Cria estrutura de diretórios"""
        for dir_path in self.dirs.values():
            Path(dir_path).mkdir(parents=True, exist_ok=True)
        print(f"✓ Diretórios criados em: {self.output_dir}")
    
    def wait_for_element(self, selector, timeout=10):
        """Aguarda elemento aparecer na página"""
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
            )
            return True
        except TimeoutException:
            return False
    
    def scroll_page(self, pause_time=2):
        """Faz scroll na página para carregar conteúdo dinâmico"""
        last_height = self.driver.execute_script("return document.body.scrollHeight")
        
        while True:
            # Scroll para baixo
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(pause_time)
            
            # Calcula nova altura
            new_height = self.driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break
            last_height = new_height
    
    def extract_page_data(self, url):
        """Extrai dados completos de uma página"""
        print(f"\n[EXTRAÇÃO] Processando: {url}")
        
        try:
            self.driver.get(url)
            time.sleep(3)  # Aguarda carregamento
            
            # Scroll para carregar conteúdo dinâmico
            self.scroll_page(pause_time=1)
            
            # Capturar HTML renderizado
            html = self.driver.page_source
            soup = BeautifulSoup(html, 'html.parser')
            
            page_data = {
                'url': url,
                'title': soup.title.string if soup.title else '',
                'timestamp': datetime.now().isoformat(),
                'screenshot': self.take_screenshot(url),
                'html_file': self.save_html(url, html),
                'properties': self.extract_properties(soup),
                'forms': self.extract_forms(soup),
                'links': self.extract_links(soup),
                'images': self.extract_images(url, soup),
                'text_content': self.extract_text(soup),
                'metadata': self.extract_metadata(soup)
            }
            
            self.all_data['pages'].append(page_data)
            print(f"✓ Página processada: {len(page_data['properties'])} propriedades encontradas")
            
            return page_data
        
        except Exception as e:
            print(f"✗ Erro ao processar {url}: {e}")
            return None
    
    def take_screenshot(self, url):
        """Captura screenshot da página"""
        try:
            filename = f"screenshot_{len(self.all_data['pages'])}.png"
            filepath = os.path.join(self.dirs['screenshots'], filename)
            self.driver.save_screenshot(filepath)
            return filename
        except Exception as e:
            print(f"✗ Erro ao capturar screenshot: {e}")
            return None
    
    def save_html(self, url, html):
        """Salva HTML renderizado"""
        try:
            parsed = urlparse(url)
            filename = os.path.basename(parsed.path) or f"page_{len(self.all_data['pages'])}.html"
            if not filename.endswith('.html'):
                filename += '.html'
            
            filepath = os.path.join(self.dirs['html'], filename)
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(html)
            
            return filename
        except Exception as e:
            print(f"✗ Erro ao salvar HTML: {e}")
            return None
    
    def extract_properties(self, soup):
        """Extrai dados de propriedades/imóveis"""
        properties = []
        
        # Procura por padrões comuns de cards de imóveis
        selectors = [
            'div[id*="destaque"]',
            'div[class*="property"]',
            'div[class*="imovel"]',
            'article[class*="property"]',
            'div[class*="card"]'
        ]
        
        for selector in selectors:
            items = soup.select(selector)
            for item in items:
                prop_data = {
                    'id': item.get('id', ''),
                    'class': item.get('class', []),
                    'title': '',
                    'description': '',
                    'price': '',
                    'location': '',
                    'bedrooms': '',
                    'bathrooms': '',
                    'area': '',
                    'image': '',
                    'link': '',
                    'raw_html': str(item)[:500]
                }
                
                # Extrair informações
                title_elem = item.find(['h2', 'h3', 'h4', 'a'])
                if title_elem:
                    prop_data['title'] = title_elem.get_text(strip=True)
                
                # Preço
                price_elem = item.find(text=re.compile(r'R\$|USD|\$'))
                if price_elem:
                    prop_data['price'] = price_elem.strip()
                
                # Descrição
                desc_elem = item.find(['p', 'span', 'div'], {'class': re.compile(r'desc|description')})
                if desc_elem:
                    prop_data['description'] = desc_elem.get_text(strip=True)[:200]
                
                # Imagem
                img = item.find('img')
                if img:
                    prop_data['image'] = img.get('src', '')
                
                # Link
                link = item.find('a')
                if link:
                    prop_data['link'] = link.get('href', '')
                
                # Números (quartos, banheiros, área)
                text = item.get_text()
                bedrooms = re.search(r'(\d+)\s*(?:quarto|bedroom|br)', text, re.IGNORECASE)
                if bedrooms:
                    prop_data['bedrooms'] = bedrooms.group(1)
                
                bathrooms = re.search(r'(\d+)\s*(?:banheiro|bathroom|ba)', text, re.IGNORECASE)
                if bathrooms:
                    prop_data['bathrooms'] = bathrooms.group(1)
                
                area = re.search(r'(\d+(?:[.,]\d+)?)\s*(?:m²|m2|sqm)', text, re.IGNORECASE)
                if area:
                    prop_data['area'] = area.group(1)
                
                if prop_data['title']:  # Só adiciona se tem título
                    properties.append(prop_data)
        
        return properties
    
    def extract_forms(self, soup):
        """Extrai dados de formulários"""
        forms = []
        
        for form in soup.find_all('form'):
            form_data = {
                'id': form.get('id', ''),
                'name': form.get('name', ''),
                'action': form.get('action', ''),
                'method': form.get('method', 'GET'),
                'fields': []
            }
            
            for field in form.find_all(['input', 'textarea', 'select']):
                form_data['fields'].append({
                    'type': field.name,
                    'input_type': field.get('type', ''),
                    'name': field.get('name', ''),
                    'id': field.get('id', ''),
                    'placeholder': field.get('placeholder', ''),
                    'required': field.get('required') is not None
                })
            
            forms.append(form_data)
        
        return forms
    
    def extract_links(self, soup):
        """Extrai todos os links"""
        links = []
        
        for link in soup.find_all('a'):
            href = link.get('href', '')
            if href and not href.startswith('#'):
                links.append({
                    'text': link.get_text(strip=True),
                    'href': href,
                    'title': link.get('title', '')
                })
        
        return links
    
    def extract_images(self, base_url, soup):
        """Extrai e baixa imagens"""
        images = []
        
        for i, img in enumerate(soup.find_all('img')):
            src = img.get('src', '')
            if src:
                full_url = urljoin(base_url, src)
                
                try:
                    response = self.session.get(full_url, timeout=5)
                    if response.status_code == 200:
                        # Extrair nome do arquivo
                        parsed = urlparse(full_url)
                        filename = os.path.basename(parsed.path) or f'image_{i}.jpg'
                        
                        filepath = os.path.join(self.dirs['images'], filename)
                        with open(filepath, 'wb') as f:
                            f.write(response.content)
                        
                        images.append({
                            'url': full_url,
                            'local_file': filename,
                            'alt': img.get('alt', ''),
                            'title': img.get('title', '')
                        })
                except Exception as e:
                    print(f"  ✗ Erro ao baixar imagem {full_url}: {e}")
        
        return images
    
    def extract_text(self, soup):
        """Extrai conteúdo de texto"""
        # Remove scripts e styles
        for script in soup(["script", "style"]):
            script.decompose()
        
        text = soup.get_text()
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)
        
        return text[:5000]  # Primeiros 5000 caracteres
    
    def extract_metadata(self, soup):
        """Extrai metadados da página"""
        metadata = {
            'title': soup.title.string if soup.title else '',
            'description': '',
            'keywords': '',
            'og_title': '',
            'og_description': '',
            'og_image': ''
        }
        
        for meta in soup.find_all('meta'):
            name = meta.get('name', '').lower()
            prop = meta.get('property', '').lower()
            content = meta.get('content', '')
            
            if 'description' in name:
                metadata['description'] = content
            elif 'keywords' in name:
                metadata['keywords'] = content
            elif 'og:title' in prop:
                metadata['og_title'] = content
            elif 'og:description' in prop:
                metadata['og_description'] = content
            elif 'og:image' in prop:
                metadata['og_image'] = content
        
        return metadata
    
    def crawl_site(self):
        """Faz crawling de múltiplas páginas"""
        print("\n" + "="*70)
        print("INICIANDO CRAWLING DO SITE")
        print("="*70)
        
        to_visit = [self.base_url]
        page_count = 0
        
        while to_visit and page_count < self.max_pages:
            url = to_visit.pop(0)
            
            if url in self.visited_urls:
                continue
            
            # Verificar se é do mesmo domínio
            if urlparse(url).netloc != urlparse(self.base_url).netloc:
                continue
            
            self.visited_urls.add(url)
            page_count += 1
            
            print(f"\n[{page_count}/{self.max_pages}] Processando: {url}")
            
            page_data = self.extract_page_data(url)
            
            if page_data:
                # Extrair novos links para visitar
                for link in page_data['links']:
                    href = link['href']
                    if href and not href.startswith('#'):
                        full_url = urljoin(self.base_url, href)
                        if full_url not in self.visited_urls:
                            to_visit.append(full_url)
            
            time.sleep(2)  # Respeitar servidor
        
        print(f"\n✓ Crawling concluído: {page_count} páginas processadas")
    
    def extract_api_calls(self):
        """Detecta chamadas de API"""
        print("\n[API] Detectando chamadas de API...")
        
        # Executar script para capturar requisições de rede
        try:
            logs = self.driver.get_log('performance')
            
            for log in logs:
                message = json.loads(log['message'])['message']
                
                if message['method'] == 'Network.responseReceived':
                    response = message['params']['response']
                    url = response['url']
                    
                    if '/api/' in url or url.endswith('.json'):
                        self.all_data['api_calls'].append({
                            'url': url,
                            'status': response.get('status', ''),
                            'type': response.get('type', '')
                        })
        except Exception as e:
            print(f"  ℹ Não foi possível capturar logs de API: {e}")
    
    def generate_database(self):
        """Gera banco de dados JSON com todos os dados"""
        print("\n[DATABASE] Gerando banco de dados...")
        
        db_file = os.path.join(self.dirs['data'], 'database.json')
        with open(db_file, 'w', encoding='utf-8') as f:
            json.dump(self.all_data, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Banco de dados gerado: {db_file}")
    
    def generate_csv_export(self):
        """Exporta propriedades para CSV"""
        print("\n[CSV] Exportando dados para CSV...")
        
        try:
            import csv
            
            csv_file = os.path.join(self.dirs['data'], 'properties.csv')
            
            if self.all_data['properties']:
                with open(csv_file, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.DictWriter(f, fieldnames=self.all_data['properties'][0].keys())
                    writer.writeheader()
                    writer.writerows(self.all_data['properties'])
                
                print(f"✓ CSV gerado: {csv_file}")
        except Exception as e:
            print(f"✗ Erro ao gerar CSV: {e}")
    
    def generate_report(self):
        """Gera relatório completo"""
        print("\n[REPORT] Gerando relatório...")
        
        report = f"""# RELATÓRIO MASTER DOWNLOADER

## Resumo da Execução
- **Data**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **URL Base**: {self.base_url}
- **Diretório**: {self.output_dir}

## Estatísticas
- **Páginas Processadas**: {len(self.all_data['pages'])}
- **Propriedades Encontradas**: {len(self.all_data['properties'])}
- **Imagens Baixadas**: {sum(len(p.get('images', [])) for p in self.all_data['pages'])}
- **Formulários**: {len(self.all_data['forms'])}
- **Links Únicos**: {len(set(l['href'] for p in self.all_data['pages'] for l in p.get('links', [])))}
- **Chamadas de API**: {len(self.all_data['api_calls'])}

## Páginas Processadas
"""
        
        for i, page in enumerate(self.all_data['pages'], 1):
            report += f"\n### {i}. {page['title']}\n"
            report += f"- URL: {page['url']}\n"
            report += f"- Propriedades: {len(page['properties'])}\n"
            report += f"- Imagens: {len(page['images'])}\n"
            report += f"- Screenshot: {page['screenshot']}\n"
        
        report += f"\n## Propriedades Encontradas\n"
        for prop in self.all_data['properties'][:20]:  # Primeiras 20
            report += f"\n- **{prop['title']}**\n"
            report += f"  - Preço: {prop['price']}\n"
            report += f"  - Quartos: {prop['bedrooms']}\n"
            report += f"  - Banheiros: {prop['bathrooms']}\n"
            report += f"  - Área: {prop['area']}\n"
        
        if len(self.all_data['properties']) > 20:
            report += f"\n... e mais {len(self.all_data['properties']) - 20} propriedades\n"
        
        report_file = os.path.join(self.dirs['docs'], 'MASTER_REPORT.md')
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"✓ Relatório gerado: {report_file}")
    
    def download_all(self):
        """Executa download completo MASTER"""
        print(f"\n{'='*70}")
        print("IMOBSSA MASTER DOWNLOADER v2.0")
        print(f"{'='*70}")
        print(f"URL: {self.base_url}")
        print(f"Modo: MASTER (Selenium + Crawling + Dados Dinâmicos)")
        print(f"{'='*70}")
        
        try:
            # Setup
            self.create_directories()
            if not self.setup_selenium():
                return False
            
            # Crawling
            self.crawl_site()
            
            # Extração de API
            self.extract_api_calls()
            
            # Consolidar propriedades
            for page in self.all_data['pages']:
                self.all_data['properties'].extend(page.get('properties', []))
            
            # Geração de dados
            self.generate_database()
            self.generate_csv_export()
            self.generate_report()
            
            # Resumo final
            self.print_summary()
            
            return True
        
        except Exception as e:
            print(f"\n✗ Erro durante execução: {e}")
            return False
        
        finally:
            if self.driver:
                self.driver.quit()
                print("\n✓ WebDriver fechado")
    
    def print_summary(self):
        """Imprime resumo final"""
        print(f"\n{'='*70}")
        print("RESUMO FINAL")
        print(f"{'='*70}")
        print(f"✓ Páginas processadas: {len(self.all_data['pages'])}")
        print(f"✓ Propriedades encontradas: {len(self.all_data['properties'])}")
        print(f"✓ Imagens baixadas: {sum(len(p.get('images', [])) for p in self.all_data['pages'])}")
        print(f"✓ Screenshots capturados: {len([p for p in self.all_data['pages'] if p['screenshot']])}")
        print(f"✓ Formulários extraídos: {len(self.all_data['forms'])}")
        print(f"✓ Chamadas de API detectadas: {len(self.all_data['api_calls'])}")
        print(f"\n✓ Dados salvos em: {self.output_dir}")
        print(f"{'='*70}\n")

if __name__ == '__main__':
    downloader = ImobssaMasterDownloader(
        base_url="https://imobssa.com.br",
        output_dir="imobssa_master_clone",
        max_pages=20  # Aumentar para mais páginas
    )
    downloader.download_all()
