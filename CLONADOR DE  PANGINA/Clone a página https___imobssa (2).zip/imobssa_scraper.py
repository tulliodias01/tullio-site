#!/usr/bin/env python3
"""
Script de Análise Técnica e Scraping do Site ImobSSA
Extrai estrutura, dados e documenta arquitetura para reconstrução
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from urllib.parse import urljoin
import time

class ImobssaScraper:
    def __init__(self, base_url="https://imobssa.com.br"):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        self.data = {
            'metadata': {},
            'structure': {},
            'scripts': [],
            'stylesheets': [],
            'forms': [],
            'properties': [],
            'api_endpoints': [],
            'technical_stack': {}
        }
    
    def fetch_page(self, url):
        """Baixa a página HTML"""
        try:
            response = self.session.get(url, timeout=10)
            response.encoding = 'utf-8'
            return response.text
        except Exception as e:
            print(f"Erro ao baixar {url}: {e}")
            return None
    
    def extract_metadata(self, soup):
        """Extrai metadados da página"""
        self.data['metadata'] = {
            'title': soup.title.string if soup.title else '',
            'description': soup.find('meta', {'name': 'description'}).get('content', '') if soup.find('meta', {'name': 'description'}) else '',
            'keywords': soup.find('meta', {'name': 'keywords'}).get('content', '') if soup.find('meta', {'name': 'keywords'}) else '',
            'viewport': soup.find('meta', {'name': 'viewport'}).get('content', '') if soup.find('meta', {'name': 'viewport'}) else '',
            'charset': soup.find('meta', {'charset'}).get('charset', 'utf-8') if soup.find('meta', {'charset'}) else 'utf-8',
            'og_image': soup.find('meta', {'property': 'og:image'}).get('content', '') if soup.find('meta', {'property': 'og:image'}) else '',
            'canonical': soup.find('link', {'rel': 'canonical'}).get('href', '') if soup.find('link', {'rel': 'canonical'}) else ''
        }
    
    def extract_scripts(self, soup):
        """Extrai informações sobre scripts carregados"""
        scripts = soup.find_all('script')
        for script in scripts:
            if script.get('src'):
                self.data['scripts'].append({
                    'type': 'external',
                    'src': urljoin(self.base_url, script.get('src')),
                    'async': script.get('async') is not None,
                    'defer': script.get('defer') is not None
                })
            elif script.string:
                content = script.string.lower()
                if 'jquery' in content:
                    self.data['technical_stack']['jquery'] = True
                if 'react' in content:
                    self.data['technical_stack']['react'] = True
                if 'gtag' in content or 'google' in content:
                    self.data['technical_stack']['google_analytics'] = True
                if 'fbq' in content:
                    self.data['technical_stack']['facebook_pixel'] = True
    
    def extract_stylesheets(self, soup):
        """Extrai informações sobre stylesheets"""
        links = soup.find_all('link', {'rel': 'stylesheet'})
        for link in links:
            href = link.get('href', '')
            self.data['stylesheets'].append({
                'href': urljoin(self.base_url, href),
                'media': link.get('media', 'all')
            })
    
    def extract_forms(self, soup):
        """Extrai informações sobre formulários"""
        forms = soup.find_all('form')
        for form in forms:
            form_data = {
                'id': form.get('id', ''),
                'name': form.get('name', ''),
                'action': urljoin(self.base_url, form.get('action', '')),
                'method': form.get('method', 'get').upper(),
                'fields': []
            }
            
            for field in form.find_all(['input', 'textarea', 'select']):
                form_data['fields'].append({
                    'type': field.name,
                    'input_type': field.get('type', ''),
                    'name': field.get('name', ''),
                    'id': field.get('id', ''),
                    'placeholder': field.get('placeholder', ''),
                    'required': field.get('required') is not None
                })
            
            self.data['forms'].append(form_data)
    
    def extract_properties(self, soup):
        """Extrai dados de imóveis da página"""
        property_selectors = [
            'div[id*="destaque"]',
            'div[class*="property"]',
            'div[class*="imovel"]',
            'article[class*="property"]'
        ]
        
        for selector in property_selectors:
            properties = soup.select(selector)
            for prop in properties:
                prop_text = prop.get_text(strip=True)
                if prop_text:
                    self.data['properties'].append({
                        'selector': selector,
                        'id': prop.get('id', ''),
                        'class': prop.get('class', []),
                        'text_preview': prop_text[:200]
                    })
    
    def extract_api_endpoints(self, soup):
        """Detecta endpoints de API e requisições AJAX"""
        script_contents = ' '.join([s.string or '' for s in soup.find_all('script')])
        
        patterns = [
            r'https?://[^\s"\'<>]+/api/[^\s"\'<>]+',
            r'https?://[^\s"\'<>]+\.json',
            r'/api/[^\s"\'<>]+',
            r'\.php\?[^\s"\'<>]+'
        ]
        
        endpoints = set()
        for pattern in patterns:
            matches = re.findall(pattern, script_contents)
            endpoints.update(matches)
        
        self.data['api_endpoints'] = list(endpoints)[:20]
    
    def extract_structure(self, soup):
        """Analisa estrutura HTML geral"""
        self.data['structure'] = {
            'total_elements': len(soup.find_all()),
            'divs': len(soup.find_all('div')),
            'sections': len(soup.find_all(['section', 'article', 'main'])),
            'forms': len(soup.find_all('form')),
            'images': len(soup.find_all('img')),
            'links': len(soup.find_all('a')),
            'body_classes': soup.body.get('class', []) if soup.body else []
        }
    
    def scrape(self):
        """Executa o scraping completo"""
        print(f"Iniciando scraping de {self.base_url}...")
        
        html = self.fetch_page(self.base_url)
        if not html:
            return False
        
        soup = BeautifulSoup(html, 'html.parser')
        
        print("Extraindo metadados...")
        self.extract_metadata(soup)
        
        print("Extraindo scripts...")
        self.extract_scripts(soup)
        
        print("Extraindo stylesheets...")
        self.extract_stylesheets(soup)
        
        print("Extraindo formulários...")
        self.extract_forms(soup)
        
        print("Extraindo propriedades...")
        self.extract_properties(soup)
        
        print("Detectando endpoints de API...")
        self.extract_api_endpoints(soup)
        
        print("Analisando estrutura...")
        self.extract_structure(soup)
        
        return True
    
    def save_report(self, filename='imobssa_technical_report.json'):
        """Salva relatório técnico em JSON"""
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
        print(f"Relatório salvo em {filename}")
    
    def generate_documentation(self, filename='TECHNICAL_ANALYSIS.md'):
        """Gera documentação técnica em Markdown"""
        doc = f"""# Análise Técnica - ImobSSA

## Metadados
- **Título**: {self.data['metadata'].get('title', 'N/A')}
- **Descrição**: {self.data['metadata'].get('description', 'N/A')}
- **Charset**: {self.data['metadata'].get('charset', 'N/A')}

## Stack Técnico Detectado
"""
        for tech, detected in self.data['technical_stack'].items():
            if detected:
                doc += f"- ✓ {tech}\n"
        
        doc += f"""
## Estrutura HTML
- Total de elementos: {self.data['structure'].get('total_elements', 0)}
- Divs: {self.data['structure'].get('divs', 0)}
- Seções: {self.data['structure'].get('sections', 0)}
- Formulários: {self.data['structure'].get('forms', 0)}
- Imagens: {self.data['structure'].get('images', 0)}
- Links: {self.data['structure'].get('links', 0)}

## Scripts Externos ({len(self.data['scripts'])})
"""
        for script in self.data['scripts'][:10]:
            doc += f"- {script['src']}\n"
        
        doc += f"""
## Stylesheets ({len(self.data['stylesheets'])})
"""
        for stylesheet in self.data['stylesheets']:
            doc += f"- {stylesheet['href']}\n"
        
        doc += f"""
## Formulários ({len(self.data['forms'])})
"""
        for form in self.data['forms']:
            doc += f"""
### {form['id'] or form['name']}
- **Action**: {form['action']}
- **Method**: {form['method']}
- **Campos**: {len(form['fields'])}
"""
        
        doc += f"""
## API Endpoints Detectados ({len(self.data['api_endpoints'])})
"""
        for endpoint in self.data['api_endpoints']:
            doc += f"- {endpoint}\n"
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(doc)
        print(f"Documentação salva em {filename}")

if __name__ == '__main__':
    scraper = ImobssaScraper()
    
    if scraper.scrape():
        scraper.save_report()
        scraper.generate_documentation()
        
        print("\n" + "="*50)
        print("RESUMO DA ANÁLISE")
        print("="*50)
        print(f"Scripts: {len(scraper.data['scripts'])}")
        print(f"Stylesheets: {len(scraper.data['stylesheets'])}")
        print(f"Formulários: {len(scraper.data['forms'])}")
        print(f"Propriedades encontradas: {len(scraper.data['properties'])}")
        print(f"Endpoints de API: {len(scraper.data['api_endpoints'])}")
        print(f"Stack: {list(scraper.data['technical_stack'].keys())}")
    else:
        print("Erro ao fazer scraping")
