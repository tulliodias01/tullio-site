# 🚀 Guia MASTER - Script Avançado com Selenium

## 📋 O Que é o Script MASTER?

Script **PROFISSIONAL** que captura **100% do site**, incluindo:

✅ **Dados Dinâmicos** - Conteúdo carregado por JavaScript/AJAX
✅ **Múltiplas Páginas** - Crawling automático de todas as páginas
✅ **Screenshots** - Captura visual de cada página
✅ **Banco de Dados** - JSON com todos os dados estruturados
✅ **CSV Export** - Exporta propriedades em Excel
✅ **Relatório Completo** - Análise detalhada

---

## 📦 Instalação no Windows

### Passo 1: Instalar Python (se ainda não tiver)

1. Acesse: https://www.python.org/downloads/
2. Baixe Python 3.11+
3. Execute o instalador
4. **IMPORTANTE:** Marque ✅ "Add Python to PATH"
5. Clique "Install Now"

---

### Passo 2: Instalar Dependências

Abra o **Prompt de Comando** e execute:

```bash
pip install selenium beautifulsoup4 requests
```

Você deve ver:
```
Successfully installed selenium-4.x.x beautifulsoup4-4.x.x requests-2.x.x
```

---

### Passo 3: Baixar ChromeDriver

O Selenium precisa do ChromeDriver para controlar o navegador.

1. Acesse: https://chromedriver.chromium.org/
2. Baixe a versão que corresponde ao seu Chrome
   - Abra Chrome → Menu (⋮) → Ajuda → Sobre o Google Chrome
   - Veja a versão (ex: 123.0.6312.86)
   - Baixe a mesma versão do ChromeDriver

3. Extraia o arquivo `chromedriver.exe`

4. Coloque em uma das pastas:
   - `C:\Windows\System32\` (recomendado)
   - Ou na mesma pasta do script

---

### Passo 4: Copiar o Script

1. Crie uma pasta: `C:\Users\SeuUsuario\Downloads\master_scraper`
2. Copie o arquivo `imobssa_master_downloader.py` para essa pasta

---

## 🎯 Como Usar

### Opção 1: Executar no Prompt de Comando

```bash
cd C:\Users\SeuUsuario\Downloads\master_scraper
python imobssa_master_downloader.py
```

### Opção 2: Criar Arquivo .bat

Crie um arquivo `rodar_master.bat` com o conteúdo:

```batch
@echo off
cd /d "%~dp0"
python imobssa_master_downloader.py
pause
```

Duplo clique para executar.

---

## 🌐 Usar com Outros Sites

Edite o final do arquivo `imobssa_master_downloader.py`:

```python
# ANTES
if __name__ == '__main__':
    downloader = ImobssaMasterDownloader(
        base_url="https://imobssa.com.br",
        output_dir="imobssa_master_clone",
        max_pages=20
    )

# DEPOIS - Para outro site
if __name__ == '__main__':
    downloader = ImobssaMasterDownloader(
        base_url="https://www.seu-site.com.br",
        output_dir="seu_site_clone",
        max_pages=50  # Aumentar para mais páginas
    )
```

---

## 📊 Exemplos Prontos

### Shopee
```python
downloader = ImobssaMasterDownloader(
    base_url="https://www.shopee.com.br",
    output_dir="shopee_master_clone",
    max_pages=30
)
```

### Mercado Livre
```python
downloader = ImobssaMasterDownloader(
    base_url="https://www.mercadolivre.com.br",
    output_dir="mercadolivre_master_clone",
    max_pages=30
)
```

### G1 (Notícias)
```python
downloader = ImobssaMasterDownloader(
    base_url="https://www.g1.globo.com",
    output_dir="g1_master_clone",
    max_pages=20
)
```

---

## 📁 Estrutura de Saída

Após executar, você terá:

```
imobssa_master_clone/
├── html/                          # Páginas HTML renderizadas
│   ├── index.html
│   ├── page_1.html
│   └── ...
├── css/                           # Stylesheets
├── js/                            # Scripts JavaScript
├── images/                        # Todas as imagens baixadas
├── screenshots/                   # Screenshots de cada página
│   ├── screenshot_0.png
│   ├── screenshot_1.png
│   └── ...
├── data/
│   ├── database.json             # Banco de dados completo
│   ├── properties.csv            # Propriedades em CSV
│   └── structure.json
└── docs/
    └── MASTER_REPORT.md          # Relatório detalhado
```

---

## 📊 O Que Está no database.json

```json
{
  "metadata": { ... },
  "pages": [
    {
      "url": "https://imobssa.com.br",
      "title": "Imob - A maior central...",
      "properties": [ ... ],
      "forms": [ ... ],
      "images": [ ... ],
      "screenshot": "screenshot_0.png"
    }
  ],
  "properties": [
    {
      "title": "Rivage Piatã | Sertenge",
      "price": "R$ 317.100,00",
      "bedrooms": "1",
      "bathrooms": "1",
      "area": "998",
      "location": "Piatã",
      "image": "...",
      "link": "..."
    }
  ],
  "api_calls": [ ... ]
}
```

---

## 📈 Configurações Avançadas

### Aumentar Número de Páginas

```python
downloader = ImobssaMasterDownloader(
    base_url="https://imobssa.com.br",
    output_dir="imobssa_master_clone",
    max_pages=100  # Aumentar aqui
)
```

### Aumentar Timeout

Edite a linha no script:

```python
# Procure por: time.sleep(3)
# Mude para: time.sleep(5)  # Aguarda 5 segundos
```

### Desabilitar Headless (Ver o Navegador)

Procure por:
```python
# options.add_argument('--headless')
```

Remova o `#` para ver o navegador funcionando:
```python
options.add_argument('--headless')
```

---

## 🆘 Problemas Comuns

### Problema 1: "chromedriver not found"

**Solução:**
1. Baixe ChromeDriver: https://chromedriver.chromium.org/
2. Extraia em `C:\Windows\System32\`
3. Reinicie o computador

---

### Problema 2: "Selenium module not found"

**Solução:**
```bash
pip install selenium
```

---

### Problema 3: "Chrome version mismatch"

**Solução:**
1. Abra Chrome → Menu (⋮) → Ajuda → Sobre o Google Chrome
2. Veja a versão
3. Baixe ChromeDriver da mesma versão
4. Substitua o arquivo

---

### Problema 4: Script muito lento

**Solução:**
- Reduzir `max_pages`
- Aumentar `time.sleep()` (se pular conteúdo)
- Usar internet mais rápida

---

### Problema 5: Algumas imagens não baixam

**Solução:**
- Normal - alguns sites bloqueiam downloads
- O script continua mesmo com erros
- Verifique a pasta `images/` para ver o que foi baixado

---

## 🚀 Próximos Passos

### 1. Analisar os Dados

```bash
# Abrir database.json em um editor de texto
# Ou usar um visualizador JSON online
```

### 2. Importar em Excel

```bash
# Abrir properties.csv no Excel
# Dados já estruturados em colunas
```

### 3. Usar os Screenshots

```bash
# Visualizar screenshots em screenshots/
# Útil para entender o layout
```

### 4. Reconstruir o Site

Com todos os dados capturados, você pode:
- Criar seu próprio site com os dados
- Integrar com seu banco de dados
- Implementar suas funcionalidades

---

## 💡 Dicas Profissionais

### ✅ Boas Práticas

1. **Respeite o servidor**
   - Não configure `max_pages` muito alto
   - Deixe delays entre requisições

2. **Verifique robots.txt**
   ```
   https://seu-site.com.br/robots.txt
   ```

3. **Trate erros graciosamente**
   - O script continua mesmo com falhas
   - Verifique o relatório para ver o que funcionou

4. **Salve os dados**
   - Faça backup do `database.json`
   - Exporte para CSV regularmente

---

## 📊 Comparação: Básico vs MASTER

| Recurso | Básico | MASTER |
|---------|--------|--------|
| HTML estático | ✅ | ✅ |
| CSS/JS | ✅ | ✅ |
| Imagens | ✅ | ✅ |
| Dados dinâmicos | ❌ | ✅ |
| Múltiplas páginas | ❌ | ✅ |
| Screenshots | ❌ | ✅ |
| Banco de dados | ❌ | ✅ |
| CSV export | ❌ | ✅ |
| Relatório detalhado | ❌ | ✅ |

---

## 🎓 Recursos

- **Selenium Docs:** https://www.selenium.dev/documentation/
- **BeautifulSoup Docs:** https://www.crummy.com/software/BeautifulSoup/
- **ChromeDriver:** https://chromedriver.chromium.org/

---

## 📞 Suporte

Se tiver problemas:

1. Verifique se Python está instalado: `python --version`
2. Verifique se Selenium está instalado: `pip show selenium`
3. Verifique se ChromeDriver está no PATH: `chromedriver --version`
4. Leia o arquivo de relatório: `MASTER_REPORT.md`

---

**Versão:** 2.0 MASTER
**Data:** 2026-04-09
**Sistema:** Windows 10/11
