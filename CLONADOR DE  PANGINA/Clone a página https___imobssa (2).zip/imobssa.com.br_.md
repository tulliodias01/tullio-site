# Imob - A maior central de vendas de imóveis de Salvador

**URL:** https://imobssa.com.br/

---

Bom Dia, hoje é dia 09 de Abril de 2026 - Salvador / BA
Atendimento
71 98216-2070
Inicial
Empreendimentos
Informações
 
Rise Caminho das Árvores | Ferreira Ferraz
2 quartos no Caminho das Árvores
2 Quartos2 Banheiros2 Vagas68,90 Área Privativa
Dom Horto Florestal | Santa Helena
4 quartos no Horto Florestral
4 Quartos1.771,00 Terreno
Nest Rio Vermelho | LPL
2 e 3 quartos com suíte no Rio Vermelho
2 Quartos1 Vagas62,87 Área Privativa
Nouvelle Bossa | André Guimarães
4 e 5 suítes em Jaguaribe
2 Banheiros1 Vagas3.221,46 Terreno
Rivage Piatã | Sertenge
Stúdio, 1 e 2 quartos em frente ao mar em Piatã
1 Quartos998,00 Terreno
La Mar Jaguaribe | Gráfico
3 suítes em Jaguaribe
3 Quartos4 Banheiros2 Vagas2.478,48 Terreno

     

Vivenda Real | Tenda
2 quartos no Porto Seco Pirajá
R$ 240.000,00
Rise Caminho das Árvores | Ferreira Ferraz
2 quartos no Caminho das Árvores
R$ 875.624,00
Bosque Caminho das Árvores | JVF
2 suítes com lavabo no Caminho das Árvores
R$ 978.000,00
Nest Rio Vermelho | LPL
2 e 3 quartos com suíte no Rio Vermelho
R$ 510.300,00
Villaggio Jardins | Prima
3 e 4 suítes no coração da Cidade Jardins
R$ 1.255.060,00
Parque dos Condes | MRV
2 quartos na Cidade Sete Sóis Paralela
R$ 254.990,00
Solar dos Cajueiros | MRV
2 quartos em Abrantes
R$ 248.000,00
Beach Class Bahia | MD
Studio e 2 quartos integrado ao Shopping da Bahia
R$ 341.601,00
Rivage Piatã | Sertenge
Stúdio, 1 e 2 quartos em frente ao mar em Piatã
R$ 317.100,00
Solaris Camaçari | Tenda
2 quartos em Camaçari
R$ 218.000,00
Pituba Facilitys | LSN
Studios na Pituba
R$ 254.000,00
Residencial Ponta do Inhambupe | Prima
2, 3 e 4 quartos com pé na areia
R$ 707.250,00
Jardim Patamares | Stanza
2 e 3 quartos em Patamares
R$ 386.000,00
Ventura Patamares | Stanza
2 e 3 quartos em Pàtamares
R$ 404.000,00
Sensian Urban
2 quartos com varanda no Stiep
R$ 478.990,00
Morada Real | Tenda
2 quartos em Porto Seco Pirajá
R$ 248.000,00
Ocean Side Jaguaribe
2 e 3 quartos com vista para o mar
R$ 596.000,00
Jardim das Tulipas | S3 Engenharia
2 quartos com suíte no Jardim Brasília
R$ 377.616,00
Sensia Patamares
2 e 3 quartos com lazer completo
R$ 489.990,00
Nouvelle Bossa | André Guimarães
4 e 5 suítes em Jaguaribe
R$ 3.590.258,00
Encanto Piatã | Tenda
2 quartos em Piatã
R$ 250.000,00
Makai Praia do Forte
Casas com 2,3 ou 4 suítes
R$ 565.000,00
Move Itaigara | Sertenge
2 e 3 quartos no Itaigara
R$ 881.608,00
Selleto Salvador Norte | Sertenge
2 quartos com lazer completo no MCMV
R$ 239.906,00
VIV Rio Vermelho | Direcional
3 quartos com lazer completo
R$ 538.000,00
Vale dos Lírios | Tenda
2 quartos em Sussuarana, com benefícios do MCMV
R$ 243.000,00
Conquista Boulevard Park | Direcional
1 e 2 quartos com lazer completo
R$ 210.000,00
Golf Riviera | MRV
2 quartos no Jardim Cajazeiras
R$ 252.990,00
Top Club Residencial | Concreta
2 quartos (suíte), varanda e lazer completo na Vila Canária
R$ 330.400,00
Mood Club Costa Azul | MD
2 e 3 quartos no Costa Azul
R$ 490.909,00
Conquista Lauro | Direcional
1 e 2 quartos em Lauro de Freitas
R$ 228.000,00
Morada das Estações | Tenda
2 quartos em São Cristovão
R$ 245.000,00
La Mar Jaguaribe | Gráfico
3 suítes em Jaguaribe
R$ 1.461.828,00
Vog Itapuã | Sertenge
2 suítes com varanda e lazer completo
R$ 405.719,00
Vivai São Rafael | Sertenge
2 quartos ou 2 suítes com lazer completo em São Rafael
R$ 321.807,00
Conquista Vila Verde | Direcional
1 e 2 quartos com lazer completo em frente ao Shopping Busca Vida
R$ 224.990,00
Dom Horto Florestal | Santa Helena
4 quartos no Horto Florestral
R$ 1.702.936,00
Reserva da Mata | MRV
2 quartos em Sussuarana
R$ 252.000,00
Forte São Marcelo | Tenda
2 quartos em Areia Branca
R$ 208.000,00
Brotas Prime | Bauhaus
2 suítes em Brotas
R$ 369.667,00
Terraço Cabula | BRL Incorp
3 quartos com lazer completo no Cabula
R$ 530.000,00
Alto Paralela | Stanza
2 quartos no melhor lugar da Av. Paralela
R$ 240.000,00
Art Studio Tancredo | André Guimarães
Studio, Quarto/Sala e 2 quartos na Av. Tancredo Neves
R$ 357.705,00
Ancoratto Jaguaribe | Gráfico
2 e 3 quartos, com lazer completo, em frente a praia
R$ 790.000,00
Bela Vista Residencial | MRV
2 quartos com lazer completo em Pernambués
R$ 270.000,00
Vale das Tulipas | Tenda
2 quartos com lazer completo em Sussuarana
R$ 240.000,00
Imbui Class | Barbosa Tinel
2 e 3 quartos com lazer completo no Imbui
R$ 533.520,00
Yu Corsário Smart Hub
Studios em frente a Praia do Corsário
R$ 361.268,00
Roof Aero | 3i
2 quartos em São Cristovão
R$ 254.000,00
Vila Laura Prime | Tenda
2 quartos com lazer completo em Vila Laura
R$ 262.990,00
1
	
Newsletter


Cadastre seu e-mail e receba novidades exclusivas.


Nome: 	
E-mail: 	
Cidade: 	
2187	Repita ao lado:	
Notícias
Parceiros
Política de privacidade
Trabalhe conosco
IMOB - INTELIGÊNCIA IMOBILIÁRIA

A maior central de vendas de imóveis de Salvador

Fale com Paty, nossa atendente virtual (71) 92748-0194

Creci 1368PJ
Rua Luís Eduardo Magalhães - Paralela - Salvador/BA

(71) 98216-2070

contato@portaldaimob.com.br

Empreendimentos
Todos os Imóveis
Em Obras
Entregue
Pronto
Lançamento
Informações
Quem Somos
Mapa de Localização
Fale Conosco
www.imobssa.com.br © 2026. Todos os direitos reservados.
Site para Imobiliarias