# 🪟 Guia Completo - Scripts no Windows

## 📋 Passo a Passo

### Passo 1: Instalar Python no Windows

1. Acesse: https://www.python.org/downloads/
2. Clique em **"Download Python 3.11"** (ou versão mais recente)
3. Execute o instalador

**IMPORTANTE:** Na primeira tela, marque a caixa: ✅ **"Add Python to PATH"**

![Python Install](https://imgur.com/exemplo.png)

4. Clique em **"Install Now"**
5. Aguarde a instalação completar

---

### Passo 2: Verificar Instalação

1. Abra o **Prompt de Comando** (CMD):
   - Pressione `Win + R`
   - Digite `cmd`
   - Pressione Enter

2. Digite o comando:
```bash
python --version
```

3. Você deve ver algo como:
```
Python 3.11.0
```

Se não funcionar, reinicie o computador e tente novamente.

---

### Passo 3: Instalar Dependências

No Prompt de Comando, digite:

```bash
pip install requests beautifulsoup4
```

Aguarde até ver:
```
Successfully installed requests-2.31.0 beautifulsoup4-4.12.0
```

---

### Passo 4: Baixar os Scripts

#### Opção A: Copiar os Scripts (Recomendado)

1. Crie uma pasta em seu computador:
   - Exemplo: `C:\Users\SeuUsuario\Downloads\web_scraper`

2. Copie os 2 arquivos Python para essa pasta:
   - `imobssa_scraper.py`
   - `imobssa_complete_downloader.py`

#### Opção B: Criar os Scripts Manualmente

1. Abra o **Bloco de Notas** (Notepad)
2. Copie todo o código do arquivo `imobssa_complete_downloader.py`
3. Salve como `imobssa_complete_downloader.py` (não como .txt!)
4. Repita para o outro arquivo

---

### Passo 5: Rodar os Scripts

#### Método 1: Prompt de Comando (Recomendado)

1. Abra o **Prompt de Comando** (CMD)

2. Navegue até a pasta onde salvou os scripts:
```bash
cd C:\Users\SeuUsuario\Downloads\web_scraper
```

3. Execute o script de análise:
```bash
python imobssa_scraper.py
```

Você verá:
```
Iniciando scraping de https://imobssa.com.br...
Extraindo metadados...
Extraindo scripts...
✓ Análise concluída!
```

4. Para download completo:
```bash
python imobssa_complete_downloader.py
```

Você verá:
```
============================================================
IMOBSSA COMPLETE DOWNLOADER
============================================================
✓ Diretórios criados em: imobssa_clone
[1/6] Baixando HTML...
✓ HTML baixado
[2/6] Baixando Stylesheets...
✓ CSS baixado
... (continua)
```

---

#### Método 2: Duplo Clique (Mais Fácil)

1. Crie um arquivo chamado `rodar.bat` na mesma pasta

2. Abra com Bloco de Notas e copie:

```batch
@echo off
cd /d "%~dp0"
python imobssa_complete_downloader.py
pause
```

3. Salve como `rodar.bat`

4. Duplo clique em `rodar.bat` para executar

---

## 🌐 Usar com Outros Sites

### Método 1: Editar no Bloco de Notas

1. Clique com botão direito em `imobssa_complete_downloader.py`
2. Selecione **"Abrir com"** → **"Bloco de Notas"**
3. Procure pela última linha (perto do final):

```python
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader()
    downloader.download_all()
```

4. Mude para:

```python
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader(
        base_url="https://www.seu-site.com.br",
        output_dir="seu_site_clone"
    )
    downloader.download_all()
```

5. Salve (Ctrl + S)

6. Execute novamente

---

### Exemplos Prontos para Copiar e Colar

**Shopee:**
```python
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader(
        base_url="https://www.shopee.com.br",
        output_dir="shopee_clone"
    )
    downloader.download_all()
```

**Mercado Livre:**
```python
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader(
        base_url="https://www.mercadolivre.com.br",
        output_dir="mercadolivre_clone"
    )
    downloader.download_all()
```

**G1 (Notícias):**
```python
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader(
        base_url="https://www.g1.globo.com",
        output_dir="g1_clone"
    )
    downloader.download_all()
```

**VivaReal (Imóveis):**
```python
if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader(
        base_url="https://www.vivareal.com.br",
        output_dir="vivareal_clone"
    )
    downloader.download_all()
```

---

## 📁 Onde Encontrar os Arquivos Baixados

Após executar o script, você terá uma pasta com o nome que escolheu.

**Exemplo:** Se você rodou com `output_dir="imobssa_clone"`, terá:

```
C:\Users\SeuUsuario\Downloads\web_scraper\imobssa_clone\
├── html\
│   └── index.html
├── css\
│   ├── layout.css
│   ├── ddsmoothmenu.css
│   └── ...
├── js\
│   ├── jquery.min.js
│   ├── stepcarousel.js
│   └── ...
├── images\
│   ├── imagem1.jpg
│   ├── imagem2.png
│   └── ...
├── data\
│   └── structure.json
└── docs\
    ├── RECONSTRUCTION_GUIDE.md
    └── download_report.json
```

---

## 🆘 Problemas Comuns no Windows

### Problema 1: "python: comando não encontrado"

**Solução:**
1. Desinstale Python
2. Reinstale marcando ✅ **"Add Python to PATH"**
3. Reinicie o computador

---

### Problema 2: "ModuleNotFoundError: No module named 'requests'"

**Solução:**
```bash
pip install requests beautifulsoup4
```

Se não funcionar, tente:
```bash
python -m pip install requests beautifulsoup4
```

---

### Problema 3: Arquivo .bat não abre

**Solução:**
1. Clique com botão direito no arquivo
2. Selecione **"Abrir com"** → **"Prompt de Comando"**

---

### Problema 4: Erro de Permissão

**Solução:**
1. Abra o Prompt de Comando como **Administrador**:
   - Pressione `Win + R`
   - Digite `cmd`
   - Pressione `Ctrl + Shift + Enter`

2. Navegue até a pasta:
```bash
cd C:\Users\SeuUsuario\Downloads\web_scraper
```

3. Execute o script:
```bash
python imobssa_complete_downloader.py
```

---

## 🎯 Criar Script Genérico no Windows

Crie um arquivo `download_qualquer_site.py`:

```python
#!/usr/bin/env python3
import sys
from imobssa_complete_downloader import ImobssaCompleteDownloader

if len(sys.argv) < 2:
    url = input("Digite a URL do site: ")
    output_dir = input("Nome da pasta (padrão: site_clone): ") or "site_clone"
else:
    url = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "site_clone"

print(f"\nBaixando: {url}")
print(f"Pasta: {output_dir}\n")

downloader = ImobssaCompleteDownloader(base_url=url, output_dir=output_dir)
downloader.download_all()
```

**Como usar:**
1. Duplo clique no arquivo
2. Digite a URL do site
3. Digite o nome da pasta (ou pressione Enter para usar "site_clone")

---

## 📊 Monitorar o Progresso

Enquanto o script está rodando, você pode:

1. Abrir a pasta `imobssa_clone` (ou o nome que escolheu)
2. Ver os arquivos sendo criados em tempo real
3. Verificar o tamanho total dos arquivos baixados

---

## 💾 Salvar os Scripts para Reusar

Depois de baixar os scripts, guarde-os em um local seguro:

```
C:\Users\SeuUsuario\Documents\Scripts_Web_Scraper\
├── imobssa_scraper.py
├── imobssa_complete_downloader.py
├── rodar.bat
└── README.txt
```

Assim você pode reusar sempre que precisar!

---

## 🚀 Próximos Passos

Depois de baixar o site:

1. **Abra o HTML no navegador:**
   - Duplo clique em `imobssa_clone\html\index.html`

2. **Leia o guia de reconstrução:**
   - Abra `imobssa_clone\docs\RECONSTRUCTION_GUIDE.md`

3. **Customize o design:**
   - Edite os arquivos em `imobssa_clone\css\`
   - Edite o HTML em `imobssa_clone\html\`

4. **Implemente suas funcionalidades:**
   - Adicione backend (Node.js, Python, etc)
   - Conecte banco de dados
   - Integre com suas APIs

---

## 📞 Dicas Finais

✅ **Faça:**
- Respeite o servidor (não baixe muito rápido)
- Leia o `robots.txt` do site
- Use para fins educacionais

❌ **Não faça:**
- Não republique conteúdo protegido
- Não use para spam
- Não viole termos de serviço

---

## 🎓 Recursos Adicionais

- **Python Docs:** https://docs.python.org/3/
- **BeautifulSoup Docs:** https://www.crummy.com/software/BeautifulSoup/
- **Requests Docs:** https://requests.readthedocs.io/

---

**Versão:** 1.0
**Última atualização:** 2026-04-09
**Sistema:** Windows 10/11
