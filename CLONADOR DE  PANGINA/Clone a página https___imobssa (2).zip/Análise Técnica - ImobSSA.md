# Análise Técnica - ImobSSA

## Metadados
- **Título**: Imob - A maior central de vendas de imóveis de Salvador
- **Descrição**: Nossa equipe de corretores é formada por profissionais experientes, comprometidos com o seu projeto de vida.  Venha para a Imob.
- **Charset**: utf-8

## Stack Técnico Detectado
- ✓ facebook_pixel
- ✓ google_analytics
- ✓ jquery

## Estrutura HTML
- Total de elementos: 1280
- Divs: 682
- Seções: 0
- Formulários: 3
- Imagens: 228
- Links: 143

## Scripts Externos (6)
- https://www.googletagmanager.com/gtag/js?id=G-F8T95Y0SHE
- https://s1.src-imobibrasil.com.br/t18/Scripts/carousel/jquerymin132.js
- https://s1.src-imobibrasil.com.br/t18/Scripts/carousel/stepcarousel.js
- https://s1.src-imobibrasil.com.br/t18/Scripts/menunav/jquery.min.js
- https://s1.src-imobibrasil.com.br/t18/Scripts/menunav/ddsmoothmenu.js
- https://srv.imobibrasil.app/js/analytics.js?v=8

## Stylesheets (4)
- https://s1.src-imobibrasil.com.br/t18/layout.css
- https://s1.src-imobibrasil.com.br/t18/Scripts/menunav/ddsmoothmenu.css
- https://s1.src-imobibrasil.com.br/t18/Scripts/menunav/ddsmoothmenu-v.css
- https://s1.src-imobibrasil.com.br/Scripts/whatsapplead/whatsapplead.css?v=3

## Formulários (3)

### frm_buscatopo
- **Action**: https://imobssa.com.br/imovel/
- **Method**: GET
- **Campos**: 1

### frmAPPWhats
- **Action**: https://imobssa.com.br/contato/?acao=whats
- **Method**: POST
- **Campos**: 8

### frmnews
- **Action**: https://imobssa.com.br/newsletter/?acao=add
- **Method**: POST
- **Campos**: 7

## API Endpoints Detectados (0)
