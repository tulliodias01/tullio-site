#!/usr/bin/env python3
"""
Script Completo de Download e Análise do Site ImobSSA
Baixa toda a estrutura técnica, HTML, CSS, JS e dados para reconstrução
"""

import requests
from bs4 import BeautifulSoup
import json
import os
import re
from urllib.parse import urljoin, urlparse
from pathlib import Path
import time

class ImobssaCompleteDownloader:
    def __init__(self, base_url="https://imobssa.com.br", output_dir="imobssa_clone"):
        self.base_url = base_url
        self.output_dir = output_dir
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Criar estrutura de diretórios
        self.dirs = {
            'root': output_dir,
            'html': os.path.join(output_dir, 'html'),
            'css': os.path.join(output_dir, 'css'),
            'js': os.path.join(output_dir, 'js'),
            'images': os.path.join(output_dir, 'images'),
            'data': os.path.join(output_dir, 'data'),
            'docs': os.path.join(output_dir, 'docs')
        }
        
        self.downloaded_files = {
            'html': [],
            'css': [],
            'js': [],
            'images': [],
            'data': []
        }
    
    def create_directories(self):
        """Cria estrutura de diretórios"""
        for dir_path in self.dirs.values():
            Path(dir_path).mkdir(parents=True, exist_ok=True)
        print(f"✓ Diretórios criados em: {self.output_dir}")
    
    def download_file(self, url, output_path, category='data'):
        """Baixa um arquivo"""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            with open(output_path, 'wb') as f:
                f.write(response.content)
            
            self.downloaded_files[category].append({
                'url': url,
                'local_path': output_path,
                'size': len(response.content)
            })
            
            return True
        except Exception as e:
            print(f"✗ Erro ao baixar {url}: {e}")
            return False
    
    def download_page_html(self):
        """Baixa a página HTML principal"""
        print("\n[1/6] Baixando HTML...")
        try:
            response = self.session.get(self.base_url, timeout=10)
            response.encoding = 'utf-8'
            
            html_path = os.path.join(self.dirs['html'], 'index.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(response.text)
            
            self.downloaded_files['html'].append({
                'url': self.base_url,
                'local_path': html_path
            })
            
            print(f"✓ HTML baixado: {html_path}")
            return response.text
        except Exception as e:
            print(f"✗ Erro ao baixar HTML: {e}")
            return None
    
    def download_stylesheets(self, html_content):
        """Baixa todos os CSS"""
        print("\n[2/6] Baixando Stylesheets...")
        soup = BeautifulSoup(html_content, 'html.parser')
        
        links = soup.find_all('link', {'rel': 'stylesheet'})
        for i, link in enumerate(links):
            href = link.get('href', '')
            if href:
                full_url = urljoin(self.base_url, href)
                
                # Extrair nome do arquivo
                parsed = urlparse(full_url)
                filename = os.path.basename(parsed.path) or f'style_{i}.css'
                
                output_path = os.path.join(self.dirs['css'], filename)
                
                if self.download_file(full_url, output_path, 'css'):
                    print(f"✓ CSS baixado: {filename}")
                
                time.sleep(0.5)  # Respeitar servidor
    
    def download_scripts(self, html_content):
        """Baixa todos os scripts JS"""
        print("\n[3/6] Baixando Scripts...")
        soup = BeautifulSoup(html_content, 'html.parser')
        
        scripts = soup.find_all('script', {'src': True})
        for i, script in enumerate(scripts):
            src = script.get('src', '')
            if src:
                full_url = urljoin(self.base_url, src)
                
                # Extrair nome do arquivo
                parsed = urlparse(full_url)
                filename = os.path.basename(parsed.path) or f'script_{i}.js'
                
                output_path = os.path.join(self.dirs['js'], filename)
                
                if self.download_file(full_url, output_path, 'js'):
                    print(f"✓ JS baixado: {filename}")
                
                time.sleep(0.5)
    
    def download_images(self, html_content, limit=50):
        """Baixa imagens da página"""
        print(f"\n[4/6] Baixando Imagens (limite: {limit})...")
        soup = BeautifulSoup(html_content, 'html.parser')
        
        images = soup.find_all('img')[:limit]
        for i, img in enumerate(images):
            src = img.get('src', '')
            if src:
                full_url = urljoin(self.base_url, src)
                
                # Extrair nome do arquivo
                parsed = urlparse(full_url)
                filename = os.path.basename(parsed.path) or f'image_{i}.jpg'
                
                output_path = os.path.join(self.dirs['images'], filename)
                
                if self.download_file(full_url, output_path, 'images'):
                    print(f"✓ Imagem baixada: {filename}")
                
                time.sleep(0.3)
    
    def extract_data_structure(self, html_content):
        """Extrai estrutura de dados e padrões"""
        print("\n[5/6] Extraindo Estrutura de Dados...")
        soup = BeautifulSoup(html_content, 'html.parser')
        
        data_structure = {
            'page_title': soup.title.string if soup.title else '',
            'meta_tags': {},
            'forms': [],
            'data_containers': [],
            'navigation': [],
            'footer': {}
        }
        
        # Meta tags
        for meta in soup.find_all('meta'):
            name = meta.get('name') or meta.get('property', '')
            content = meta.get('content', '')
            if name:
                data_structure['meta_tags'][name] = content
        
        # Formulários
        for form in soup.find_all('form'):
            form_data = {
                'id': form.get('id', ''),
                'action': form.get('action', ''),
                'method': form.get('method', 'GET'),
                'fields': []
            }
            
            for field in form.find_all(['input', 'textarea', 'select']):
                form_data['fields'].append({
                    'type': field.name,
                    'name': field.get('name', ''),
                    'id': field.get('id', ''),
                    'placeholder': field.get('placeholder', '')
                })
            
            data_structure['forms'].append(form_data)
        
        # Containers de dados (imóveis)
        for container in soup.find_all(['div', 'article'], {'class': re.compile(r'(property|imovel|destaque)')}):
            data_structure['data_containers'].append({
                'id': container.get('id', ''),
                'class': container.get('class', []),
                'text_sample': container.get_text(strip=True)[:200]
            })
        
        # Navegação
        for nav in soup.find_all(['nav', 'ul', 'menu']):
            for link in nav.find_all('a'):
                data_structure['navigation'].append({
                    'text': link.get_text(strip=True),
                    'href': link.get('href', '')
                })
        
        # Footer
        footer = soup.find('footer')
        if footer:
            data_structure['footer'] = {
                'text': footer.get_text(strip=True)[:300],
                'links': [a.get('href', '') for a in footer.find_all('a')]
            }
        
        # Salvar estrutura
        data_path = os.path.join(self.dirs['data'], 'structure.json')
        with open(data_path, 'w', encoding='utf-8') as f:
            json.dump(data_structure, f, indent=2, ensure_ascii=False)
        
        print(f"✓ Estrutura de dados extraída: {data_path}")
        return data_structure
    
    def generate_reconstruction_guide(self):
        """Gera guia de reconstrução"""
        print("\n[6/6] Gerando Guia de Reconstrução...")
        
        guide = f"""# Guia de Reconstrução - ImobSSA Clone

## Arquitetura Técnica Detectada

### Stack Tecnológico
- **Frontend**: HTML5, CSS3, JavaScript (jQuery)
- **Análise**: Servidor tradicional (PHP/ASP.NET provável)
- **Analytics**: Google Analytics, Facebook Pixel
- **Hospedagem**: ImobiBrasil (plataforma especializada em imóveis)

### Estrutura de Diretórios Baixada
```
{self.output_dir}/
├── html/           # Páginas HTML
├── css/            # Stylesheets
├── js/             # Scripts JavaScript
├── images/         # Imagens
├── data/           # Dados estruturados (JSON)
└── docs/           # Documentação
```

## Arquivos Baixados

### HTML ({len(self.downloaded_files['html'])})
"""
        for file in self.downloaded_files['html']:
            guide += f"- {file['local_path']}\n"
        
        guide += f"\n### CSS ({len(self.downloaded_files['css'])})\n"
        for file in self.downloaded_files['css']:
            guide += f"- {file['local_path']}\n"
        
        guide += f"\n### JavaScript ({len(self.downloaded_files['js'])})\n"
        for file in self.downloaded_files['js']:
            guide += f"- {file['local_path']}\n"
        
        guide += f"\n### Imagens ({len(self.downloaded_files['images'])})\n"
        for file in self.downloaded_files['images'][:10]:
            guide += f"- {file['local_path']}\n"
        
        if len(self.downloaded_files['images']) > 10:
            guide += f"... e mais {len(self.downloaded_files['images']) - 10} imagens\n"
        
        guide += """
## Próximos Passos para Reconstrução

### 1. Análise do HTML
- Revisar `html/index.html` para entender a estrutura
- Identificar seções principais (header, hero, grid de imóveis, footer)
- Mapear IDs e classes importantes

### 2. Customização de Estilos
- Modificar `css/` para seu próprio design
- Ajustar cores, fontes e layout
- Adicionar responsividade se necessário

### 3. Implementação de Funcionalidades
- Integrar com seu banco de dados
- Implementar busca e filtros
- Configurar formulários de contato

### 4. Otimizações
- Minificar CSS e JS
- Otimizar imagens
- Implementar lazy loading
- Configurar cache

### 5. Deployment
- Testar em diferentes navegadores
- Validar SEO
- Configurar domínio
- Implementar SSL

## Tecnologias Recomendadas para Reconstrução

### Opção 1: Tradicional (Similar ao Original)
- Backend: PHP/Node.js/Python
- Frontend: HTML5 + CSS3 + jQuery
- Database: MySQL/PostgreSQL
- Hosting: Compartilhado ou VPS

### Opção 2: Moderna (Recomendado)
- Frontend: React/Vue.js/Next.js
- Backend: Node.js/Python/Go
- Database: PostgreSQL/MongoDB
- Hosting: Vercel/Netlify/AWS

### Opção 3: Headless CMS
- CMS: Strapi/Contentful
- Frontend: Next.js/Nuxt
- Database: Gerenciado pelo CMS
- Hosting: Serverless

## Estrutura de Dados Extraída

Veja `data/structure.json` para:
- Formulários e seus campos
- Containers de dados (imóveis)
- Navegação e links
- Meta tags e SEO

## Checklist de Reconstrução

- [ ] Revisar toda a estrutura HTML
- [ ] Customizar CSS para seu design
- [ ] Implementar lógica de backend
- [ ] Conectar banco de dados
- [ ] Testar formulários
- [ ] Otimizar performance
- [ ] Implementar SEO
- [ ] Configurar domínio
- [ ] Deploy em produção
- [ ] Monitorar e manter

## Suporte

Para dúvidas sobre reconstrução, consulte:
- Documentação oficial das tecnologias escolhidas
- Stack Overflow para problemas específicos
- Comunidades de desenvolvimento web

---
Gerado automaticamente pelo ImobSSA Downloader
"""
        
        guide_path = os.path.join(self.dirs['docs'], 'RECONSTRUCTION_GUIDE.md')
        with open(guide_path, 'w', encoding='utf-8') as f:
            f.write(guide)
        
        print(f"✓ Guia de reconstrução: {guide_path}")
    
    def generate_summary_report(self):
        """Gera relatório resumido"""
        report = {
            'download_date': time.strftime('%Y-%m-%d %H:%M:%S'),
            'source_url': self.base_url,
            'output_directory': self.output_dir,
            'files_downloaded': {
                'html': len(self.downloaded_files['html']),
                'css': len(self.downloaded_files['css']),
                'js': len(self.downloaded_files['js']),
                'images': len(self.downloaded_files['images']),
                'total': sum(len(v) for v in self.downloaded_files.values())
            },
            'total_size_mb': sum(
                sum(f.get('size', 0) for f in files) 
                for files in self.downloaded_files.values()
            ) / (1024 * 1024)
        }
        
        report_path = os.path.join(self.dirs['docs'], 'download_report.json')
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n{'='*60}")
        print("RESUMO DO DOWNLOAD")
        print(f"{'='*60}")
        print(f"Data: {report['download_date']}")
        print(f"Origem: {report['source_url']}")
        print(f"Destino: {report['output_directory']}")
        print(f"\nArquivos Baixados:")
        print(f"  - HTML: {report['files_downloaded']['html']}")
        print(f"  - CSS: {report['files_downloaded']['css']}")
        print(f"  - JS: {report['files_downloaded']['js']}")
        print(f"  - Imagens: {report['files_downloaded']['images']}")
        print(f"  - Total: {report['files_downloaded']['total']}")
        print(f"\nTamanho Total: {report['total_size_mb']:.2f} MB")
        print(f"{'='*60}\n")
    
    def download_all(self):
        """Executa download completo"""
        print(f"\n{'='*60}")
        print("IMOBSSA COMPLETE DOWNLOADER")
        print(f"{'='*60}")
        
        self.create_directories()
        
        html_content = self.download_page_html()
        if not html_content:
            print("Erro: Não foi possível baixar o HTML principal")
            return False
        
        self.download_stylesheets(html_content)
        self.download_scripts(html_content)
        self.download_images(html_content, limit=50)
        self.extract_data_structure(html_content)
        self.generate_reconstruction_guide()
        self.generate_summary_report()
        
        print(f"✓ Download completo! Arquivos em: {self.output_dir}")
        return True

if __name__ == '__main__':
    downloader = ImobssaCompleteDownloader()
    downloader.download_all()
