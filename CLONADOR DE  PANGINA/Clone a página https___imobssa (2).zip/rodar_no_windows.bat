@echo off
REM Script para rodar o downloader no Windows
REM Duplo clique para executar

cd /d "%~dp0"

echo ============================================================
echo IMOBSSA COMPLETE DOWNLOADER - Windows
echo ============================================================
echo.

REM Verificar se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo ERRO: Python não encontrado!
    echo.
    echo Instale Python em: https://www.python.org/downloads/
    echo IMPORTANTE: Marque "Add Python to PATH" durante a instalação
    echo.
    pause
    exit /b 1
)

REM Verificar dependências
python -c "import requests, bs4" >nul 2>&1
if errorlevel 1 (
    echo Instalando dependências...
    pip install requests beautifulsoup4
)

echo.
echo Iniciando download...
echo.

REM Executar o script
python imobssa_complete_downloader.py

echo.
echo ============================================================
echo Download concluído!
echo Arquivos salvos em: imobssa_clone\
echo ============================================================
echo.
pause
