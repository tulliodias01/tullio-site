import { useState } from 'react';
import { Search, MapPin, Bed, Bath, Square, DollarSign, ChevronRight, Phone, Mail, MapPinIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Property {
  id: number;
  name: string;
  location: string;
  description: string;
  price: string;
  bedrooms: number;
  bathrooms: number;
  area: string;
  status: 'LANÇAMENTO' | 'EM OBRAS' | 'ENTREGUE' | 'PRONTO';
  image: string;
}

const properties: Property[] = [
  {
    id: 1,
    name: 'Vivenda Real | Tenda',
    location: 'Porto Seco Pirajá',
    description: '2 quartos no Porto Seco Pirajá',
    price: 'R$ 240.000,00',
    bedrooms: 2,
    bathrooms: 1,
    area: '68,90 m²',
    status: 'PRONTO',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-1-RQw8eyuZp2yCsosSGWEqt8.webp'
  },
  {
    id: 2,
    name: 'Rise Caminho das Árvores | Ferreira Ferraz',
    location: 'Caminho das Árvores',
    description: '2 quartos no Caminho das Árvores',
    price: 'R$ 875.624,00',
    bedrooms: 2,
    bathrooms: 2,
    area: '68,90 m²',
    status: 'LANÇAMENTO',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-2-KowNNW2Ym4jzwqx9n6Khiz.webp'
  },
  {
    id: 3,
    name: 'Bosque Caminho das Árvores | JVF',
    location: 'Caminho das Árvores',
    description: '2 suítes com lavabo no Caminho das Árvores',
    price: 'R$ 978.000,00',
    bedrooms: 2,
    bathrooms: 2,
    area: '120,50 m²',
    status: 'EM OBRAS',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-3-6mfW9cKwPGvhDbyjHte5tt.webp'
  },
  {
    id: 4,
    name: 'Nest Rio Vermelho | LPL',
    location: 'Rio Vermelho',
    description: '2 e 3 quartos com suíte no Rio Vermelho',
    price: 'R$ 510.300,00',
    bedrooms: 3,
    bathrooms: 2,
    area: '95,30 m²',
    status: 'LANÇAMENTO',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-1-RQw8eyuZp2yCsosSGWEqt8.webp'
  },
  {
    id: 5,
    name: 'Villaggio Jardins | Prima',
    location: 'Cidade Jardim',
    description: '3 e 4 suítes no coração da Cidade Jardim',
    price: 'R$ 1.255.060,00',
    bedrooms: 4,
    bathrooms: 3,
    area: '180,00 m²',
    status: 'PRONTO',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-2-KowNNW2Ym4jzwqx9n6Khiz.webp'
  },
  {
    id: 6,
    name: 'Parque dos Condes | MRV',
    location: 'Paralela',
    description: '2 quartos na Cidade Sete Sóis Paralela',
    price: 'R$ 254.990,00',
    bedrooms: 2,
    bathrooms: 1,
    area: '65,00 m²',
    status: 'ENTREGUE',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-3-6mfW9cKwPGvhDbyjHte5tt.webp'
  },
  {
    id: 7,
    name: 'Solar dos Cajueiros | MRV',
    location: 'Abrantes',
    description: '2 quartos em Abrantes',
    price: 'R$ 248.000,00',
    bedrooms: 2,
    bathrooms: 1,
    area: '62,00 m²',
    status: 'PRONTO',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-1-RQw8eyuZp2yCsosSGWEqt8.webp'
  },
  {
    id: 8,
    name: 'Beach Class Bahia | MD',
    location: 'Shopping da Bahia',
    description: 'Studio e 2 quartos integrado ao Shopping da Bahia',
    price: 'R$ 341.601,00',
    bedrooms: 2,
    bathrooms: 1,
    area: '75,50 m²',
    status: 'LANÇAMENTO',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/featured-property-2-KowNNW2Ym4jzwqx9n6Khiz.webp'
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'LANÇAMENTO':
      return 'bg-red-600';
    case 'EM OBRAS':
      return 'bg-yellow-500';
    case 'ENTREGUE':
      return 'bg-green-600';
    case 'PRONTO':
      return 'bg-blue-600';
    default:
      return 'bg-gray-600';
  }
};

export default function Home() {
  const [searchCode, setSearchCode] = useState('');
  const [filteredProperties, setFilteredProperties] = useState(properties);

  const handleSearch = () => {
    if (searchCode.trim()) {
      const filtered = properties.filter(p =>
        p.id.toString().includes(searchCode) ||
        p.name.toLowerCase().includes(searchCode.toLowerCase())
      );
      setFilteredProperties(filtered);
    } else {
      setFilteredProperties(properties);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-sm border-b border-gray-100">
        <div className="container py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-700 to-amber-900 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">I</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">IMOB</h1>
                <p className="text-xs text-gray-600">Inteligência Imobiliária</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-amber-700">
                <Phone size={18} />
                <span className="font-semibold text-sm">(71) 98216-2070</span>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex gap-6 border-t border-gray-100 pt-4">
            <a href="#" className="text-gray-700 hover:text-amber-700 font-medium transition">Inicial</a>
            <a href="#" className="text-gray-700 hover:text-amber-700 font-medium transition">Empreendimentos</a>
            <a href="#" className="text-gray-700 hover:text-amber-700 font-medium transition">Informações</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663530918831/b3dDjUqiEyYaAt6zJLMUVo/hero-luxury-apartment-QogRpPTz6ru5EF3u6aJuF7.webp"
          alt="Hero"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent"></div>
        <div className="absolute inset-0 flex items-center">
          <div className="container">
            <h2 className="text-5xl font-bold text-white mb-2">Rivage Piatã | Sertenge</h2>
            <p className="text-xl text-gray-100 mb-6">Stúdio, 1 e 2 quartos em frente ao mar em Piatã</p>
            <div className="flex gap-8 text-white">
              <div className="flex items-center gap-2">
                <Bed size={24} />
                <div>
                  <p className="text-sm opacity-80">Quartos</p>
                  <p className="text-2xl font-bold">1-2</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Square size={24} />
                <div>
                  <p className="text-sm opacity-80">Terreno</p>
                  <p className="text-2xl font-bold">998,00 m²</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="bg-white border-b border-gray-200 py-8">
        <div className="container">
          <div className="flex gap-4 items-end">
            <div className="flex-1">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Busca por Código</label>
              <input
                type="text"
                placeholder="Digite o código do imóvel"
                value={searchCode}
                onChange={(e) => setSearchCode(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-700 focus:border-transparent"
              />
            </div>
            <Button
              onClick={handleSearch}
              className="bg-amber-700 hover:bg-amber-800 text-white px-8 py-3 rounded-lg font-semibold transition"
            >
              <Search size={20} className="mr-2" />
              Buscar
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-16">
        <div className="container">
          <h3 className="text-3xl font-bold text-gray-900 mb-2">Destaques</h3>
          <p className="text-gray-600 mb-8">Os melhores empreendimentos em Salvador</p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProperties.map((property) => (
              <div
                key={property.id}
                className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 group cursor-pointer"
              >
                {/* Image Container */}
                <div className="relative h-48 overflow-hidden bg-gray-200">
                  <img
                    src={property.image}
                    alt={property.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className={`absolute top-3 left-3 ${getStatusColor(property.status)} text-white px-3 py-1 rounded text-xs font-bold`}>
                    {property.status}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <h4 className="font-bold text-gray-900 mb-1 line-clamp-2">{property.name}</h4>
                  <div className="flex items-center gap-1 text-gray-600 text-sm mb-3">
                    <MapPin size={16} />
                    <span>{property.location}</span>
                  </div>
                  <p className="text-gray-600 text-sm mb-4">{property.description}</p>

                  {/* Features */}
                  <div className="flex gap-3 mb-4 text-xs text-gray-700">
                    <div className="flex items-center gap-1">
                      <Bed size={16} />
                      <span>{property.bedrooms}Q</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Bath size={16} />
                      <span>{property.bathrooms}B</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Square size={16} />
                      <span>{property.area}</span>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="border-t border-gray-200 pt-3">
                    <p className="text-lg font-bold text-amber-700">{property.price}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-amber-700 to-amber-900 py-16">
        <div className="container text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Encontre seu Imóvel Ideal</h2>
          <p className="text-xl text-amber-50 mb-8">A maior central de vendas de imóveis de Salvador</p>
          <Button className="bg-white text-amber-700 hover:bg-gray-100 px-8 py-3 rounded-lg font-bold text-lg transition">
            Ver Todos os Imóveis
            <ChevronRight size={20} className="ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            {/* About */}
            <div>
              <h3 className="text-white font-bold mb-4">IMOB</h3>
              <p className="text-sm">A maior central de vendas de imóveis de Salvador</p>
              <p className="text-sm mt-4">CRECI 1368PJ</p>
            </div>

            {/* Empreendimentos */}
            <div>
              <h4 className="text-white font-bold mb-4">Empreendimentos</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-amber-500 transition">Todos os Imóveis</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Em Obras</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Entregue</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Pronto</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Lançamento</a></li>
              </ul>
            </div>

            {/* Informações */}
            <div>
              <h4 className="text-white font-bold mb-4">Informações</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-amber-500 transition">Quem Somos</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Mapa de Localização</a></li>
                <li><a href="#" className="hover:text-amber-500 transition">Fale Conosco</a></li>
              </ul>
            </div>

            {/* Contato */}
            <div>
              <h4 className="text-white font-bold mb-4">Contato</h4>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <Phone size={16} className="mt-1 flex-shrink-0" />
                  <span>(71) 98216-2070</span>
                </div>
                <div className="flex items-start gap-2">
                  <Mail size={16} className="mt-1 flex-shrink-0" />
                  <span>contato@portaldaimob.com.br</span>
                </div>
                <div className="flex items-start gap-2">
                  <MapPinIcon size={16} className="mt-1 flex-shrink-0" />
                  <span>Rua Luís Eduardo Magalhães<br />Paralela - Salvador/BA</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom */}
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>www.imobssa.com.br © 2026. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
