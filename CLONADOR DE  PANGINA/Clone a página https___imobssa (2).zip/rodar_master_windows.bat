@echo off
REM Script MASTER Downloader - Windows
REM Duplo clique para executar

chcp 65001 >nul
cd /d "%~dp0"

echo.
echo ============================================================
echo IMOBSSA MASTER DOWNLOADER v2.0
echo ============================================================
echo.

REM Verificar Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERRO: Python não encontrado!
    echo.
    echo Instale em: https://www.python.org/downloads/
    echo IMPORTANTE: Marque "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

REM Verificar Selenium
python -c "import selenium" >nul 2>&1
if errorlevel 1 (
    echo Instalando Selenium...
    pip install selenium beautifulsoup4 requests
)

REM Verificar ChromeDriver
chromedriver --version >nul 2>&1
if errorlevel 1 (
    echo AVISO: ChromeDriver não encontrado!
    echo.
    echo Baixe em: https://chromedriver.chromium.org/
    echo Coloque em: C:\Windows\System32\
    echo.
    echo Continuando mesmo assim...
    echo.
)

echo Iniciando MASTER Downloader...
echo.

python imobssa_master_downloader.py

echo.
echo ============================================================
echo Download MASTER concluído!
echo Dados salvos em: imobssa_master_clone\
echo ============================================================
echo.
pause
