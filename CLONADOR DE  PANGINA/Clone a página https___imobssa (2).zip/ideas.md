# ImobSSA Clone - Design Brainstorm

## Análise da Página Original

### Estrutura Principal
- **Header**: Logo ImobSSA (laranja/marrom), telefone de atendimento, navegação (Inicial, Empreendimentos, Informações)
- **Busca**: Campo de busca por código de imóvel + botão buscar
- **Hero Section**: Destaque com imagem grande de imóvel + informações (quartos, banheiros, vagas, área)
- **Grid de Imóveis**: Cartões em grid 4 colunas com imagem, nome, localização, preço
- **Status Badges**: "LANÇAMENTO", "EM OBRAS", "ENTREGUE" em cores diferentes
- **Footer**: Links, newsletter, contato, redes sociais

### Paleta de Cores Atual
- Laranja/Marrom principal (#C85A17 aproximadamente)
- Verde para badges/destaques
- Branco e cinza para fundo
- Texto escuro

---

## Três Propostas de Design

<response>
<text>

### Proposta 1: Elegância Corporativa Moderna
**Design Movement**: Minimalism Corporativo com toques de Luxury Design

**Core Principles**:
- Hierarquia clara e espaçamento generoso
- Tipografia sofisticada (serif + sans-serif)
- Uso estratégico de cor (marrom/bronze como primária)
- Fotografia como protagonista

**Color Philosophy**:
- Primária: Bronze/Marrom escuro (#8B6F47) - sofisticação e confiança
- Secundária: Branco puro (#FFFFFF) - clareza
- Acentos: Dourado (#D4AF37) - luxo
- Neutros: Cinza claro (#F5F5F5) para fundos
- Texto: Charcoal (#2C2C2C)

**Layout Paradigm**:
- Hero com imagem full-width + overlay de gradiente
- Grid assimétrico (imagem grande + 3 pequenas)
- Seções com alternância de fundo branco/cinza
- Sidebar com filtros sofisticados

**Signature Elements**:
- Linhas decorativas em dourado
- Ícones minimalistas em bronze
- Cards com sombra suave e border sutil
- Tipografia em serif para títulos

**Interaction Philosophy**:
- Hover effects suaves (mudança de cor + elevação)
- Transições smooth em 300ms
- Feedback visual claro em formulários

**Animation**:
- Fade-in ao scroll (imagens)
- Subtle scale-up no hover de cards
- Slide-in lateral para modais

**Typography System**:
- Display: Playfair Display (serif, bold) - títulos principais
- Body: Lato (sans-serif, regular) - corpo de texto
- Accent: Montserrat (sans-serif, semibold) - CTAs e destaques

</text>
<probability>0.07</probability>
</response>

<response>
<text>

### Proposta 2: Dinâmica Urbana Contemporânea
**Design Movement**: Contemporary Urban + Geometric Abstraction

**Core Principles**:
- Cores vibrantes e contrastantes
- Tipografia bold e geométrica
- Layouts assimétricos e dinâmicos
- Padrões geométricos como elementos decorativos

**Color Philosophy**:
- Primária: Laranja vibrante (#FF6B35) - energia e movimento
- Secundária: Azul profundo (#004E89) - confiança
- Acentos: Amarelo limão (#FFEB3B) - destaque
- Fundos: Branco e cinza muito claro
- Texto: Preto profundo (#1A1A1A)

**Layout Paradigm**:
- Hero com imagem + texto em posição diagonal
- Grid com cards em tamanhos variados
- Seções com shapes geométricos (triângulos, linhas)
- Navegação sticky com fundo semi-transparente

**Signature Elements**:
- Formas geométricas abstratas (triângulos, linhas diagonais)
- Badges com bordas arredondadas e cores vibrantes
- Ícones geométricos customizados
- Padrão de fundo sutil (linhas paralelas)

**Interaction Philosophy**:
- Hover com mudança de cor + rotação suave
- Cliques com efeito ripple
- Transições mais rápidas (200ms)

**Animation**:
- Bounce ao entrar em viewport
- Rotate no hover
- Slide com easing cubic-bezier

**Typography System**:
- Display: Bebas Neue (sans-serif, bold) - títulos
- Body: Poppins (sans-serif, regular) - corpo
- Accent: Roboto Mono (monospace, semibold) - preços

</text>
<probability>0.08</probability>
</response>

<response>
<text>

### Proposta 3: Naturalismo Orgânico + Sustentabilidade
**Design Movement**: Organic Modern + Eco-Conscious Design

**Core Principles**:
- Formas naturais e curvilíneas
- Paleta terrosa e sustentável
- Tipografia humanista e acessível
- Foco em bem-estar e comunidade

**Color Philosophy**:
- Primária: Terra queimada (#A0522D) - natureza e estabilidade
- Secundária: Verde sálvia (#6B8E23) - crescimento sustentável
- Acentos: Coral suave (#E8A87C) - calor humano
- Fundos: Bege natural (#F5E6D3)
- Texto: Marrom escuro (#3E2723)

**Layout Paradigm**:
- Hero com imagem + forma orgânica (blob shape)
- Grid com cards com cantos arredondados suaves
- Seções com ondas/curvas como divisores
- Espaçamento assimétrico mas harmônico

**Signature Elements**:
- Formas blob/orgânicas como decoração
- Ondas SVG como divisores de seção
- Ícones com traços suaves
- Texturas sutis (papel, linho)

**Interaction Philosophy**:
- Hover com mudança suave de cor
- Transições fluidas (400ms)
- Feedback tátil visual

**Animation**:
- Floating animation em elementos decorativos
- Fade-in suave ao scroll
- Morph entre shapes ao interagir

**Typography System**:
- Display: Outfit (sans-serif, bold) - títulos
- Body: Inter (sans-serif, regular) - corpo
- Accent: DM Sans (sans-serif, semibold) - destaques

</text>
<probability>0.06</probability>
</response>

---

## Design Escolhido: **Elegância Corporativa Moderna**

A escolha recai sobre a **Proposta 1** por ser a mais alinhada com o segmento imobiliário de alto padrão. A sofisticação visual transmite confiança, profissionalismo e qualidade - atributos essenciais para uma central de vendas de imóveis premium em Salvador.

### Justificativa
- **Confiança**: Bronze e dourado evocam solidez e luxo
- **Clareza**: Hierarquia visual forte facilita navegação
- **Fotografia**: Imóveis são o protagonista, não a interface
- **Escalabilidade**: Design funciona bem em mobile e desktop
- **Diferenciação**: Sai do padrão genérico de portais imobiliários

